﻿using MySql.Data.MySqlClient;
using Parma_Project.PersonalAccountAdmin;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parma_Project.PersonalAccountEmployee
{
    public partial class SearchEmployee : Form
    {
        String IDUser = "";
        String IDSearch = "";
        bool AdminMode;
        public SearchEmployee(String ID, bool admin)
        {
            this.IDUser = ID;
            this.AdminMode = admin;
            Button button = new Button();
            button.Text = "Вернуться в ЛК Админа";
            button.Font = new Font("Montserrat", 12, FontStyle.Regular);
            button.ForeColor = Color.White;
            button.BackColor = Color.FromArgb(255, 67, 70);
            button.AutoSize = true;
            button.Location = new Point(39, 29);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.Name = "BackAdminButton";
            button.Click += new EventHandler(BackAdminButton_Click);
            this.Controls.Add(button);
            InitializeComponent();
        }
        private void BackAdminButton_Click(object sender, EventArgs e)
        {
            FunctionsAdmin admin = new FunctionsAdmin();
            admin.Show();
            this.Close();
        }
        public SearchEmployee(String ID)
        {
            this.IDUser = ID;
            this.AdminMode = false;
            InitializeComponent();
        }

        //ВОЗМОЖНОСТЬ ПЕРЕДВИЖЕНИЯ ОКНА ПРОГРАММЫ
        Point lastPoint; //точка последнего местоположения мыши
        private void PersonalAccountStranger_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void PersonalAccountStranger_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void HeaderLogo_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void HeaderLogo_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        //НАЖАТИЕ ВСЕХ ВОЗМОЖНЫХ КНОПОК
        private void CloseButton_Click(object sender, EventArgs e) //закрытие программы
        {
            this.Close();
            Application.Exit();
        }

        private void RedactionButton_Click(object sender, EventArgs e) //редакция личного профиля
        {
            if (!AdminMode)
            {
                PersonalAccountEmlpoyee personalAccountEmlpoyeeRedaction = new PersonalAccountEmlpoyee(this.IDUser);
                personalAccountEmlpoyeeRedaction.Show();
                this.Close();
            }
            else
            {
                PersonalAccountEmlpoyee personalAccountEmlpoyeeRedaction = new PersonalAccountEmlpoyee(this.IDUser, true);
                personalAccountEmlpoyeeRedaction.Show();
                this.Close();
            }
        }

        private void MapButton_Click(object sender, EventArgs e) //перейти к карте офиса
        {
            if (!AdminMode)
            {
                OfficeMap1 officeMap1 = new OfficeMap1(this.IDUser);
                officeMap1.Show(); 
                this.Close();
            }
            else
            {
                OfficeMap1 officeMap1 = new OfficeMap1(this.IDUser, true);
                officeMap1.Show();
                this.Close();
            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            try
            {
                //int.Parse(FIOEmployee.Text);
                string FIO = FIOEmployee.Text;
                //this.IDSearch = IDEmployee.Text;

                DB db = new DB();

                DataTable table = new DataTable();

                MySqlDataAdapter adapter = new MySqlDataAdapter();

                db.openConnection();
                MySqlCommand command = new MySqlCommand("SELECT * FROM `users` WHERE `FIO` = @usFIO", db.getConnection());
                command.Parameters.Add("@usFIO", MySqlDbType.VarChar).Value = FIO;
                adapter.SelectCommand = command;
                try
                {
                    adapter.Fill(table);
                }
                catch
                {
                    MessageBox.Show("Ошибка при вводе ID Сотрудника.");
                }
                db.closeConnection();
                if (table.Rows.Count > 0) //если ввод верный
                {
                    db.openConnection();
                    string IDUser, EmailUser, PhoneUser;
                    command = new MySqlCommand("SELECT id FROM `users` WHERE `FIO` = @usFIO", db.getConnection());
                    command.Parameters.Add("@usFIO", MySqlDbType.VarChar).Value = FIO;
                    IDUser = command.ExecuteScalar().ToString();
                    this.IDSearch = IDUser;
                    db.closeConnection(); db.openConnection();
                    command = new MySqlCommand("SELECT Email FROM `users` WHERE `ID` = @usID", db.getConnection());
                    command.Parameters.Add("@usID", MySqlDbType.VarChar).Value = this.IDSearch;
                    EmailUser = command.ExecuteScalar().ToString();
                    db.closeConnection(); db.openConnection();
                    command = new MySqlCommand("SELECT Phone FROM `users` WHERE `ID` = @usID", db.getConnection());
                    command.Parameters.Add("@usID", MySqlDbType.VarChar).Value = this.IDSearch;
                    PhoneUser = command.ExecuteScalar().ToString();
                    db.closeConnection();
                    ShowStranger showStranger = new ShowStranger(FIO, EmailUser, PhoneUser);
                    showStranger.Show();
                    db.closeConnection();
                }
                else
                    MessageBox.Show("Ошибка при вводе ID Сотрудника."); //пользователь не авторизован
                                                                        //если ввод неверный, то повторная попытка ввода
            }
            catch
            {
                MessageBox.Show("Ошибка при вводе ID Сотрудника.");
            }
         
        }

        private void IDEmployee_TextChanged(object sender, EventArgs e)
        {

        }

        private void SearchEmployee_Load(object sender, EventArgs e)
        {

        }
    }
}
