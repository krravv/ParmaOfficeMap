﻿namespace Parma_Project.PersonalAccountEmployee
{
    partial class SearchEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MapButton = new System.Windows.Forms.Button();
            this.CloseButton = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.StrangerPersonalAccountButton = new System.Windows.Forms.Button();
            this.RedactionButton = new System.Windows.Forms.Button();
            this.FIOEmployee = new System.Windows.Forms.TextBox();
            this.SearchButton = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.HeaderLogo = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HeaderLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // MapButton
            // 
            this.MapButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.MapButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MapButton.FlatAppearance.BorderSize = 0;
            this.MapButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MapButton.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MapButton.ForeColor = System.Drawing.Color.White;
            this.MapButton.Location = new System.Drawing.Point(670, 25);
            this.MapButton.Name = "MapButton";
            this.MapButton.Size = new System.Drawing.Size(301, 38);
            this.MapButton.TabIndex = 6;
            this.MapButton.Text = "Перейти к Карте офиса";
            this.MapButton.UseVisualStyleBackColor = false;
            this.MapButton.Click += new System.EventHandler(this.MapButton_Click);
            // 
            // CloseButton
            // 
            this.CloseButton.AutoSize = true;
            this.CloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.CloseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CloseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CloseButton.ForeColor = System.Drawing.Color.White;
            this.CloseButton.Location = new System.Drawing.Point(977, 0);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(30, 29);
            this.CloseButton.TabIndex = 5;
            this.CloseButton.Text = "X";
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.StrangerPersonalAccountButton);
            this.panel1.Controls.Add(this.RedactionButton);
            this.panel1.Location = new System.Drawing.Point(12, 146);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 204);
            this.panel1.TabIndex = 7;
            // 
            // StrangerPersonalAccountButton
            // 
            this.StrangerPersonalAccountButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.StrangerPersonalAccountButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.StrangerPersonalAccountButton.FlatAppearance.BorderSize = 0;
            this.StrangerPersonalAccountButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StrangerPersonalAccountButton.Font = new System.Drawing.Font("Montserrat", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StrangerPersonalAccountButton.ForeColor = System.Drawing.Color.White;
            this.StrangerPersonalAccountButton.Location = new System.Drawing.Point(17, 109);
            this.StrangerPersonalAccountButton.Name = "StrangerPersonalAccountButton";
            this.StrangerPersonalAccountButton.Size = new System.Drawing.Size(167, 67);
            this.StrangerPersonalAccountButton.TabIndex = 7;
            this.StrangerPersonalAccountButton.Text = "Посмотреть Личный профиль другого Сотрудника";
            this.StrangerPersonalAccountButton.UseVisualStyleBackColor = false;
            // 
            // RedactionButton
            // 
            this.RedactionButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.RedactionButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RedactionButton.FlatAppearance.BorderSize = 0;
            this.RedactionButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RedactionButton.Font = new System.Drawing.Font("Montserrat", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RedactionButton.ForeColor = System.Drawing.Color.White;
            this.RedactionButton.Location = new System.Drawing.Point(17, 29);
            this.RedactionButton.Name = "RedactionButton";
            this.RedactionButton.Size = new System.Drawing.Size(167, 51);
            this.RedactionButton.TabIndex = 5;
            this.RedactionButton.Text = "Редактировать свой профиль";
            this.RedactionButton.UseVisualStyleBackColor = false;
            this.RedactionButton.Click += new System.EventHandler(this.RedactionButton_Click);
            // 
            // FIOEmployee
            // 
            this.FIOEmployee.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.FIOEmployee.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.FIOEmployee.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FIOEmployee.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(34)))), ((int)(((byte)(50)))));
            this.FIOEmployee.Location = new System.Drawing.Point(324, 255);
            this.FIOEmployee.Name = "FIOEmployee";
            this.FIOEmployee.Size = new System.Drawing.Size(578, 32);
            this.FIOEmployee.TabIndex = 27;
            this.FIOEmployee.TextChanged += new System.EventHandler(this.IDEmployee_TextChanged);
            // 
            // SearchButton
            // 
            this.SearchButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.SearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SearchButton.FlatAppearance.BorderSize = 0;
            this.SearchButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SearchButton.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SearchButton.ForeColor = System.Drawing.Color.White;
            this.SearchButton.Location = new System.Drawing.Point(545, 293);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(123, 41);
            this.SearchButton.TabIndex = 28;
            this.SearchButton.Text = "Найти";
            this.SearchButton.UseVisualStyleBackColor = false;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(34)))), ((int)(((byte)(50)))));
            this.label4.Location = new System.Drawing.Point(319, 225);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(194, 27);
            this.label4.TabIndex = 29;
            this.label4.Text = "ФИО Сотрудника";
            // 
            // HeaderLogo
            // 
            this.HeaderLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.HeaderLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.HeaderLogo.Image = global::Parma_Project.Properties.Resources.PARMA_TG_logo_с_охранным_полем_01;
            this.HeaderLogo.Location = new System.Drawing.Point(0, 0);
            this.HeaderLogo.Name = "HeaderLogo";
            this.HeaderLogo.Size = new System.Drawing.Size(1006, 103);
            this.HeaderLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.HeaderLogo.TabIndex = 4;
            this.HeaderLogo.TabStop = false;
            this.HeaderLogo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.HeaderLogo_MouseDown);
            this.HeaderLogo.MouseMove += new System.Windows.Forms.MouseEventHandler(this.HeaderLogo_MouseMove);
            // 
            // SearchEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(236)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(1006, 507);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.FIOEmployee);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.MapButton);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.HeaderLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SearchEmployee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PersonalAccountStranger";
            this.Load += new System.EventHandler(this.SearchEmployee_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PersonalAccountStranger_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PersonalAccountStranger_MouseMove);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.HeaderLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button MapButton;
        private System.Windows.Forms.Label CloseButton;
        private System.Windows.Forms.PictureBox HeaderLogo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button StrangerPersonalAccountButton;
        private System.Windows.Forms.Button RedactionButton;
        private System.Windows.Forms.TextBox FIOEmployee;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.Label label4;
    }
}