﻿namespace Parma_Project.PersonalAccountEmployee
{
    partial class RedactionPersonalAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CloseButton = new System.Windows.Forms.Label();
            this.HeaderLogo = new System.Windows.Forms.PictureBox();
            this.SaveButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ChangePhotoButton = new System.Windows.Forms.Button();
            this.AvatarProfil = new System.Windows.Forms.PictureBox();
            this.FIOBox = new System.Windows.Forms.TextBox();
            this.PhoneBox = new System.Windows.Forms.TextBox();
            this.EmailBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.HeaderLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AvatarProfil)).BeginInit();
            this.SuspendLayout();
            // 
            // CloseButton
            // 
            this.CloseButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.CloseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CloseButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CloseButton.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CloseButton.ForeColor = System.Drawing.Color.White;
            this.CloseButton.Location = new System.Drawing.Point(645, 29);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(329, 42);
            this.CloseButton.TabIndex = 5;
            this.CloseButton.Text = "Не редактировать данные";
            this.CloseButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // HeaderLogo
            // 
            this.HeaderLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.HeaderLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.HeaderLogo.Image = global::Parma_Project.Properties.Resources.PARMA_TG_logo_с_охранным_полем_01;
            this.HeaderLogo.Location = new System.Drawing.Point(0, 0);
            this.HeaderLogo.Name = "HeaderLogo";
            this.HeaderLogo.Size = new System.Drawing.Size(1006, 103);
            this.HeaderLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.HeaderLogo.TabIndex = 4;
            this.HeaderLogo.TabStop = false;
            this.HeaderLogo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.HeaderLogo_MouseDown);
            this.HeaderLogo.MouseMove += new System.Windows.Forms.MouseEventHandler(this.HeaderLogo_MouseMove);
            // 
            // SaveButton
            // 
            this.SaveButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.SaveButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SaveButton.FlatAppearance.BorderSize = 0;
            this.SaveButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SaveButton.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SaveButton.ForeColor = System.Drawing.Color.White;
            this.SaveButton.Location = new System.Drawing.Point(357, 436);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(301, 38);
            this.SaveButton.TabIndex = 24;
            this.SaveButton.Text = "Сохранить изменения";
            this.SaveButton.UseVisualStyleBackColor = false;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(34)))), ((int)(((byte)(50)))));
            this.label2.Location = new System.Drawing.Point(227, 297);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 27);
            this.label2.TabIndex = 22;
            this.label2.Text = "Email";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(34)))), ((int)(((byte)(50)))));
            this.label1.Location = new System.Drawing.Point(227, 222);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(189, 27);
            this.label1.TabIndex = 21;
            this.label1.Text = "Номер телефона";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(34)))), ((int)(((byte)(50)))));
            this.label3.Location = new System.Drawing.Point(227, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 27);
            this.label3.TabIndex = 20;
            this.label3.Text = "ФИО";
            // 
            // ChangePhotoButton
            // 
            this.ChangePhotoButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.ChangePhotoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ChangePhotoButton.FlatAppearance.BorderSize = 0;
            this.ChangePhotoButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChangePhotoButton.Font = new System.Drawing.Font("Montserrat", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChangePhotoButton.ForeColor = System.Drawing.Color.White;
            this.ChangePhotoButton.Location = new System.Drawing.Point(53, 278);
            this.ChangePhotoButton.Name = "ChangePhotoButton";
            this.ChangePhotoButton.Size = new System.Drawing.Size(145, 30);
            this.ChangePhotoButton.TabIndex = 19;
            this.ChangePhotoButton.Text = "Изменить фото";
            this.ChangePhotoButton.UseVisualStyleBackColor = false;
            // 
            // AvatarProfil
            // 
            this.AvatarProfil.BackColor = System.Drawing.Color.White;
            this.AvatarProfil.Location = new System.Drawing.Point(53, 150);
            this.AvatarProfil.Name = "AvatarProfil";
            this.AvatarProfil.Size = new System.Drawing.Size(145, 120);
            this.AvatarProfil.TabIndex = 18;
            this.AvatarProfil.TabStop = false;
            // 
            // FIOBox
            // 
            this.FIOBox.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FIOBox.Location = new System.Drawing.Point(232, 178);
            this.FIOBox.Name = "FIOBox";
            this.FIOBox.Size = new System.Drawing.Size(575, 32);
            this.FIOBox.TabIndex = 25;
            // 
            // PhoneBox
            // 
            this.PhoneBox.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PhoneBox.Location = new System.Drawing.Point(232, 250);
            this.PhoneBox.Name = "PhoneBox";
            this.PhoneBox.Size = new System.Drawing.Size(575, 32);
            this.PhoneBox.TabIndex = 26;
            // 
            // EmailBox
            // 
            this.EmailBox.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.EmailBox.Location = new System.Drawing.Point(232, 325);
            this.EmailBox.Name = "EmailBox";
            this.EmailBox.Size = new System.Drawing.Size(575, 32);
            this.EmailBox.TabIndex = 27;
            // 
            // RedactionPersonalAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(236)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(1006, 507);
            this.Controls.Add(this.EmailBox);
            this.Controls.Add(this.PhoneBox);
            this.Controls.Add(this.FIOBox);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ChangePhotoButton);
            this.Controls.Add(this.AvatarProfil);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.HeaderLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "RedactionPersonalAccount";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RedactionPersonalAccount";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.RedactionPersonalAccount_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.RedactionPersonalAccount_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.HeaderLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AvatarProfil)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label CloseButton;
        private System.Windows.Forms.PictureBox HeaderLogo;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button ChangePhotoButton;
        private System.Windows.Forms.PictureBox AvatarProfil;
        private System.Windows.Forms.TextBox FIOBox;
        private System.Windows.Forms.TextBox PhoneBox;
        private System.Windows.Forms.TextBox EmailBox;
    }
}