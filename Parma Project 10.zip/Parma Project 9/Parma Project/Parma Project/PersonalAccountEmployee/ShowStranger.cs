﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace Parma_Project.PersonalAccountEmployee
{
    public partial class ShowStranger : Form
    {
        String IDUser = "";
        public ShowStranger(string FIOUs, string EmailUs, string PhoneUs)
        {
            Label FIO = new Label();
            FIO.Location = new Point(260, 170);
            FIO.Text = FIOUs;
            FIO.Font = new Font("Montserrat", 11, FontStyle.Regular);
            FIO.AutoSize = true;
            Controls.Add(FIO);

            Label Email = new Label();
            Email.Location = new Point(260, 243);
            Email.Text = EmailUs;
            Email.Font = new Font("Montserrat", 11, FontStyle.Regular);
            Email.AutoSize = true;
            Controls.Add(Email);

            Label Phone = new Label();
            Phone.Location = new Point(260, 320);
            Phone.Text = PhoneUs;
            Phone.AutoSize = true;
            Phone.Font = new Font("Montserrat", 11, FontStyle.Regular);
            Controls.Add(Phone);

            InitializeComponent();

            DB db = new DB();
            DataTable table = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();

            db.openConnection();
            MySqlCommand command = new MySqlCommand("SELECT id FROM `users` WHERE `FIO` = @usFIO", db.getConnection());
            command.Parameters.Add("@usFIO", MySqlDbType.VarChar).Value = FIO.Text;
            IDUser = command.ExecuteScalar().ToString(); //айдишник сотрудника/админа
            db.closeConnection();

        }
            //ВОЗМОЖНОСТЬ ПЕРЕДВИЖЕНИЯ ОКНА ПРОГРАММЫ
            Point lastPoint; //точка последнего местоположения мыши
        private void ShowStranger_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void ShowStranger_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void HeaderLogo_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void HeaderLogo_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        //НАЖАТИЕ ВСЕХ ВОЗМОЖНЫХ КНОПОК

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BookingHistory_Click(object sender, EventArgs e)
        {
            Excel.Application xlApp = new Excel.Application();
            Excel.Worksheet xlSheet;
            Excel.Range xlSheetRange;
            try
            {
                xlApp.Workbooks.Add(Type.Missing);
                xlApp.Interactive = false;
                xlApp.EnableEvents = false;
                xlSheet = (Excel.Worksheet)xlApp.Sheets[1];
                xlSheet.Name = "История бронирования";
                System.Data.DataTable dt = GetData();

                int collInd = 0, rowInd = 0;
                string data = " ";

                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    data = dt.Columns[i].ColumnName.ToString();
                    switch (data)
                    {
                        case "id table": data = "Рабочее место"; break;
                        case "period1": data = "Начало брони"; break;
                        case "period2": data = "Конец брони"; break;
                        case "id employee": data = "Сотрудник"; break;
                    }
                    xlSheet.Cells[1, i + 1] = data;
                    xlSheet.StandardWidth = data.Length + 2;
                    xlSheetRange = xlSheet.get_Range("A1:D1");
                    xlSheetRange.WrapText = true;
                    xlSheetRange.Font.Bold = true;
                    releaseObject(xlSheetRange);
                }
                for (rowInd = 0; rowInd < dt.Rows.Count; rowInd++)
                {
                    for (collInd = 0; collInd < dt.Columns.Count; collInd++)
                    {
                        data = dt.Rows[rowInd].ItemArray[collInd].ToString();
                        xlSheet.Cells[rowInd + 2, collInd + 1] = data;
                    }
                }
                releaseObject(xlSheet);
            }
            catch
            {
                MessageBox.Show("Ошибка при заполнении Excel.");
            }
            finally
            {
                xlApp.Visible = true;
                xlApp.Interactive = true;
                xlApp.ScreenUpdating = true;
                xlApp.UserControl = true;
                releaseObject(xlApp);
            }
        }
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show(ex.ToString(), "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                GC.Collect();
            }
        }
        private System.Data.DataTable GetData()
        {
            DB db = new DB();
            System.Data.DataTable dt = new System.Data.DataTable();
            try
            {
                db.openConnection();
                MySqlCommand command = new MySqlCommand("SELECT * FROM `booking history` WHERE `id employee` = @idUser", db.getConnection());
                command.Parameters.Add("@idUser", MySqlDbType.VarChar).Value = this.IDUser;
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dt = ds.Tables[0];
            }
            catch
            {
                MessageBox.Show("Ошибка при открытии базы данных.");
            }
            finally
            {
                db.closeConnection();
            }
            return dt;
        }
        private void ShowStranger_Load(object sender, EventArgs e)
        {

        }

        private void PhotoBox_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            db.openConnection();
            MySqlCommand command = new MySqlCommand("SELECT photo FROM `users` WHERE `id` = @idUser", db.getConnection());
            command.Parameters.Add("@idUser", MySqlDbType.VarChar).Value = this.IDUser;
            string link = command.ExecuteScalar().ToString();
            db.closeConnection();
            System.Diagnostics.Process.Start(link);
        }
    }
}
