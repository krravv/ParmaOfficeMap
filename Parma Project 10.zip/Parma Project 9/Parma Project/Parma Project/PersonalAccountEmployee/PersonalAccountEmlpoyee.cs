﻿using MySql.Data.MySqlClient;
using Parma_Project.PersonalAccountAdmin;
using Parma_Project.PersonalAccountEmployee;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.VisualBasic;

namespace Parma_Project
{
    public partial class PersonalAccountEmlpoyee : Form
    {
        String id = "";
        String login = "";
        bool AdminMode;
        private void ActionKostructor(string ID)
        {
            DB db = new DB();

            DataTable table = new DataTable();

            MySqlDataAdapter adapter = new MySqlDataAdapter();

            db.openConnection();
            MySqlCommand command = new MySqlCommand("SELECT * FROM `users` WHERE `ID` = @usID", db.getConnection());
            command.Parameters.Add("@usID", MySqlDbType.VarChar).Value = ID;
            adapter.SelectCommand = command;
            adapter.Fill(table);
            db.closeConnection();
            if (table.Rows.Count > 0) //если ввод верный
            {
                db.openConnection();
                string FIOUser, EmailUser, PhoneUser;
                command = new MySqlCommand("SELECT FIO FROM `users` WHERE `ID` = @usID", db.getConnection());
                command.Parameters.Add("@usID", MySqlDbType.VarChar).Value = ID;
                FIOUser = command.ExecuteScalar().ToString();
                db.closeConnection(); db.openConnection();
                command = new MySqlCommand("SELECT Email FROM `users` WHERE `ID` = @usID", db.getConnection());
                command.Parameters.Add("@usID", MySqlDbType.VarChar).Value = ID;
                EmailUser = command.ExecuteScalar().ToString();
                db.closeConnection(); db.openConnection();
                command = new MySqlCommand("SELECT Phone FROM `users` WHERE `ID` = @usID", db.getConnection());
                command.Parameters.Add("@usID", MySqlDbType.VarChar).Value = ID;
                PhoneUser = command.ExecuteScalar().ToString();
                db.closeConnection();
                db.openConnection();
                command = new MySqlCommand("SELECT login FROM `users` WHERE `ID` = @usID", db.getConnection());
                command.Parameters.Add("@usID", MySqlDbType.VarChar).Value = ID;
                this.login = command.ExecuteScalar().ToString();

                Label FIO = new Label();
                FIO.Location = new Point(415, 150);
                FIO.Text = FIOUser;
                FIO.Font = new Font("Montserrat", 11, FontStyle.Regular);
                FIO.AutoSize = true;
                Controls.Add(FIO);

                Label Phone = new Label();
                Phone.Location = new Point(415, 220);
                Phone.Text = PhoneUser;
                Phone.AutoSize = true;
                Phone.Font = new Font("Montserrat", 11, FontStyle.Regular);
                Controls.Add(Phone);

                Label Email = new Label();
                Email.Location = new Point(415, 300);
                Email.Text = EmailUser;
                Email.Font = new Font("Montserrat", 11, FontStyle.Regular);
                Email.AutoSize = true;
                Controls.Add(Email);
            }
            else
                MessageBox.Show("Ошибка при вводе ID Сотрудника."); //пользователь не авторизован
            //если ввод неверный, то повторная попытка ввода
        }
        public PersonalAccountEmlpoyee(String ID, bool admin)
        {
            this.id = ID;
            this.AdminMode = admin;
            Button button = new Button();
            button.Text = "Вернуться в ЛК Админа";
            button.Font = new Font("Montserrat", 12, FontStyle.Regular);
            button.ForeColor = Color.White;
            button.BackColor = Color.FromArgb(255, 67, 70);
            button.AutoSize = true;
            button.Location = new Point(39, 29);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.Name = "BackAdminButton";
            button.Click += new EventHandler(BackAdminButton_Click);
            this.Controls.Add(button);

            ActionKostructor(ID);
            InitializeComponent();
        }
        private void BackAdminButton_Click(object sender, EventArgs e)
        {
            FunctionsAdmin admin = new FunctionsAdmin();
            admin.Show();
            this.Close();
        }
        public PersonalAccountEmlpoyee(String ID)
        {
            this.id = ID;
            this.AdminMode = false;
            ActionKostructor(ID);

            /*DB db = new DB();
            db.openConnection();
            MySqlCommand command = new MySqlCommand("SELECT photo FROM `users` WHERE `id` = @idUser", db.getConnection());
            command.Parameters.Add("@idUser", MySqlDbType.VarChar).Value = this.id;
            string link = command.ExecuteScalar().ToString();
            db.closeConnection();

            string nameUser = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            nameUser = nameUser.Substring(nameUser.IndexOf('\\') + 1);
            string path = $"C:\\Users\\{nameUser}\\Desktop\\photo.webp";

            WebClient webClient = new WebClient();
            webClient.DownloadFile(link, path);*/

            InitializeComponent();
        }

        //ВОЗМОЖНОСТЬ ПЕРЕДВИЖЕНИЯ ОКНА ПРОГРАММЫ
        Point lastPoint; //точка последнего местоположения мыши
        private void HeaderLogo_MouseMove_1(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void HeaderLogo_MouseDown_1(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void PersonalAccountEmlpoyeeRedaction_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void PersonalAccountEmlpoyeeRedaction_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        //НАЖАТИЕ ВСЕХ ВОЗМОЖНЫХ КНОПОК
        private void StrangerPersonalAccountButton_Click(object sender, EventArgs e) //просмотр чужого личного профиля
        {
            if (!AdminMode)
            {
                SearchEmployee personalAccountStranger = new SearchEmployee(this.id);
                personalAccountStranger.Show();
                this.Close();
            }
            else
            {
                SearchEmployee personalAccountStranger = new SearchEmployee(this.id, true);
                personalAccountStranger.Show();
                this.Close();
            }
        }

        private void MapButton_Click(object sender, EventArgs e) //перейти к карте офиса
        {
            if (!AdminMode)
            {
                OfficeMap1 officeMap1 = new OfficeMap1(id);
                officeMap1.Show();
                this.Close();
            }
            else
            {
                OfficeMap1 officeMap1 = new OfficeMap1(id, true);
                officeMap1.Show();
                this.Close();
            }
        }

        private void ChangeButton_Click(object sender, EventArgs e) //сохранить изменения в личном профиле
        {
            if (!AdminMode)
            {
                RedactionPersonalAccount redaction = new RedactionPersonalAccount(this.id);
                redaction.Show();
                this.Close();
            }
            else
            {
                RedactionPersonalAccount redaction = new RedactionPersonalAccount(this.id, true);
                redaction.Show();
                this.Close();
            }
        }
        private void CloseButton_Click(object sender, EventArgs e) //закрытие программы
        {
            this.Close();
            Application.Exit();
        }

        private void UploadBookingButton_Click(object sender, EventArgs e)
        {
            Excel.Application xlApp = new Excel.Application();
            Excel.Worksheet xlSheet;
            Excel.Range xlSheetRange;
            try
            {
                xlApp.Workbooks.Add(Type.Missing);
                xlApp.Interactive = false;
                xlApp.EnableEvents = false;
                xlSheet = (Excel.Worksheet)xlApp.Sheets[1];
                xlSheet.Name = "История бронирования";
                System.Data.DataTable dt = GetData();

                int collInd = 0, rowInd = 0;
                string data = " ";

                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    data = dt.Columns[i].ColumnName.ToString();
                    switch (data)
                    {
                        case "id table": data = "Рабочее место"; break;
                        case "period1": data = "Начало брони"; break;
                        case "period2": data = "Конец брони"; break;
                        case "id employee": data = "Сотрудник"; break;
                    }
                    xlSheet.Cells[1, i + 1] = data;
                    xlSheet.StandardWidth = data.Length + 2;
                    xlSheetRange = xlSheet.get_Range("A1:D1");
                    xlSheetRange.WrapText = true;
                    xlSheetRange.Font.Bold = true;
                    releaseObject(xlSheetRange);
                }
                for (rowInd = 0; rowInd < dt.Rows.Count; rowInd++)
                {
                    for (collInd = 0; collInd < dt.Columns.Count; collInd++)
                    {
                        data = dt.Rows[rowInd].ItemArray[collInd].ToString();
                        xlSheet.Cells[rowInd + 2, collInd + 1] = data;
                    }
                }
                releaseObject(xlSheet);
            }
            catch
            {
                MessageBox.Show("Ошибка при заполнении Excel.");
            }
            finally
            {
                xlApp.Visible = true;
                xlApp.Interactive = true;
                xlApp.ScreenUpdating = true;
                xlApp.UserControl = true;
                releaseObject(xlApp);
            }
        }
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show(ex.ToString(), "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                GC.Collect();
            }
        }
        private System.Data.DataTable GetData()
        {
            DB db = new DB();
            System.Data.DataTable dt = new System.Data.DataTable();
            try
            {
                db.openConnection();
                MySqlCommand command = new MySqlCommand("SELECT * FROM `booking history` WHERE `id employee` = @idUser", db.getConnection());
                command.Parameters.Add("@idUser", MySqlDbType.VarChar).Value = this.id;
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dt = ds.Tables[0];
            }
            catch
            {
                MessageBox.Show("Ошибка при открытии базы данных.");
            }
            finally
            {
                db.closeConnection();
            }
            return dt;
        }

        private void AvatarProfil_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            db.openConnection();
            MySqlCommand command = new MySqlCommand("SELECT photo FROM `users` WHERE `id` = @idUser", db.getConnection());
            command.Parameters.Add("@idUser", MySqlDbType.VarChar).Value = this.id;
            string link = command.ExecuteScalar().ToString();
            db.closeConnection();
            System.Diagnostics.Process.Start(link);
        }

        private void ChangePhotoButton_Click(object sender, EventArgs e)
        {
            
        }
    }
}
