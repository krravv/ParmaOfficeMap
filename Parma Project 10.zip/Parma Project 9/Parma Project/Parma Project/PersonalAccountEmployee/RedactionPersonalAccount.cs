﻿using MySql.Data.MySqlClient;
using Parma_Project.PersonalAccountAdmin;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parma_Project.PersonalAccountEmployee
{
    public partial class RedactionPersonalAccount : Form
    {
        String IDUser = "";
        bool AdminMode;
        public RedactionPersonalAccount(string id, bool admin)
        {
            this.IDUser = id;
            this.AdminMode = admin;

            Button button = new Button();
            button.Text = "Вернуться в ЛК Админа";
            button.Font = new Font("Montserrat", 12, FontStyle.Regular);
            button.ForeColor = Color.White;
            button.BackColor = Color.FromArgb(255, 67, 70);
            button.AutoSize = true;
            button.Location = new Point(39, 29);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.Name = "BackAdminButton";
            button.Click += new EventHandler(BackAdminButton_Click);
            this.Controls.Add(button);
            InitializeComponent();
        }
        private void BackAdminButton_Click(object sender, EventArgs e)
        {
            FunctionsAdmin admin = new FunctionsAdmin();
            admin.Show();
            this.Close();
        }
        public RedactionPersonalAccount(string id)
        {
            this.IDUser = id;
            this.AdminMode = false;
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            DB db = new DB();
            DataTable table = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();

            string FIOUser = FIOBox.Text, PhoneUser = PhoneBox.Text, EmailUser = EmailBox.Text;
            if (FIOUser == "")
            {
                db.openConnection();
                MySqlCommand command = new MySqlCommand("SELECT FIO FROM `users` WHERE `ID` = @usID", db.getConnection());
                command.Parameters.Add("@usID", MySqlDbType.VarChar).Value = IDUser;
                adapter.SelectCommand = command;
                FIOUser = command.ExecuteScalar().ToString();
                db.closeConnection();
            }
            if (PhoneUser == "")
            {
                db.openConnection();
                MySqlCommand command = new MySqlCommand("SELECT Phone FROM `users` WHERE `ID` = @usID", db.getConnection());
                command.Parameters.Add("@usID", MySqlDbType.VarChar).Value = IDUser;
                adapter.SelectCommand = command;
                PhoneUser = command.ExecuteScalar().ToString();
                db.closeConnection();
            }
            if (EmailUser == "")
            {
                db.openConnection();
                MySqlCommand command = new MySqlCommand("SELECT Email FROM `users` WHERE `ID` = @usID", db.getConnection());
                command.Parameters.Add("@usID", MySqlDbType.VarChar).Value = IDUser;
                adapter.SelectCommand = command;
                EmailUser = command.ExecuteScalar().ToString();
                db.closeConnection();
            }

            try
            {
                db.openConnection();
                MySqlCommand updatecommand = new MySqlCommand("UPDATE `users` SET `FIO` = @name WHERE `id` = @us", db.getConnection());
                updatecommand.Parameters.Add("@name", MySqlDbType.VarChar).Value = FIOUser;
                updatecommand.Parameters.Add("@us", MySqlDbType.UInt32).Value = this.IDUser;
                updatecommand.ExecuteNonQuery();
                db.closeConnection(); db.openConnection();
                updatecommand = new MySqlCommand("UPDATE `users` SET `phone` = @numb WHERE `id` = @us", db.getConnection());
                updatecommand.Parameters.Add("@numb", MySqlDbType.VarChar).Value = PhoneUser;
                updatecommand.Parameters.Add("@us", MySqlDbType.UInt32).Value = this.IDUser;
                updatecommand.ExecuteNonQuery();
                db.closeConnection(); db.openConnection();
                updatecommand = new MySqlCommand("UPDATE `users` SET `email` = @mail WHERE `id` = @us", db.getConnection());
                updatecommand.Parameters.Add("@mail", MySqlDbType.VarChar).Value = EmailUser;
                updatecommand.Parameters.Add("@us", MySqlDbType.UInt32).Value = this.IDUser;
                updatecommand.ExecuteNonQuery();
                db.closeConnection();
                MessageBox.Show("Данные обновлены.");
            }
            catch
            {
                MessageBox.Show("Ошибка при обновлении данных.");
            }
            if (!AdminMode)
            {
                PersonalAccountEmlpoyee emlpoyee = new PersonalAccountEmlpoyee(this.IDUser);
                emlpoyee.Show();
                this.Close();
            }
            else
            {
                PersonalAccountEmlpoyee emlpoyee = new PersonalAccountEmlpoyee(this.IDUser, true);
                emlpoyee.Show();
                this.Close();
            }
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            if (!AdminMode)
            {
                PersonalAccountEmlpoyee emlpoyee = new PersonalAccountEmlpoyee(this.IDUser);
                emlpoyee.Show();
                this.Close();
            }
            else
            {
                PersonalAccountEmlpoyee emlpoyee = new PersonalAccountEmlpoyee(this.IDUser, true);
                emlpoyee.Show();
                this.Close();
            }
        }

        //ВОЗМОЖНОСТЬ ПЕРЕДВИЖЕНИЯ ОКНА ПРОГРАММЫ
        Point lastPoint; //точка последнего местоположения мыши
        private void RedactionPersonalAccount_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void RedactionPersonalAccount_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void HeaderLogo_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void HeaderLogo_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }
    }
}
