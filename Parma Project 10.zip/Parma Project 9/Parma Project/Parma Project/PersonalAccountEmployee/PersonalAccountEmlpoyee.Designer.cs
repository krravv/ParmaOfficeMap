﻿namespace Parma_Project
{
    partial class PersonalAccountEmlpoyee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CloseButton = new System.Windows.Forms.Label();
            this.MapButton = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.StrangerPersonalAccountButton = new System.Windows.Forms.Button();
            this.RedactionButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ChangeButton = new System.Windows.Forms.Button();
            this.AvatarProfil = new System.Windows.Forms.PictureBox();
            this.HeaderLogo = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ChangePhotoButton = new System.Windows.Forms.Button();
            this.UploadBookingButton = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AvatarProfil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HeaderLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // CloseButton
            // 
            this.CloseButton.AutoSize = true;
            this.CloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.CloseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CloseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CloseButton.ForeColor = System.Drawing.Color.White;
            this.CloseButton.Location = new System.Drawing.Point(977, 0);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(30, 29);
            this.CloseButton.TabIndex = 2;
            this.CloseButton.Text = "X";
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // MapButton
            // 
            this.MapButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.MapButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MapButton.FlatAppearance.BorderSize = 0;
            this.MapButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MapButton.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MapButton.ForeColor = System.Drawing.Color.White;
            this.MapButton.Location = new System.Drawing.Point(670, 21);
            this.MapButton.Name = "MapButton";
            this.MapButton.Size = new System.Drawing.Size(301, 38);
            this.MapButton.TabIndex = 3;
            this.MapButton.Text = "Перейти к Карте офиса";
            this.MapButton.UseVisualStyleBackColor = false;
            this.MapButton.Click += new System.EventHandler(this.MapButton_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.StrangerPersonalAccountButton);
            this.panel1.Controls.Add(this.RedactionButton);
            this.panel1.Location = new System.Drawing.Point(12, 146);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 202);
            this.panel1.TabIndex = 4;
            // 
            // StrangerPersonalAccountButton
            // 
            this.StrangerPersonalAccountButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.StrangerPersonalAccountButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.StrangerPersonalAccountButton.FlatAppearance.BorderSize = 0;
            this.StrangerPersonalAccountButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.StrangerPersonalAccountButton.Font = new System.Drawing.Font("Montserrat", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StrangerPersonalAccountButton.ForeColor = System.Drawing.Color.White;
            this.StrangerPersonalAccountButton.Location = new System.Drawing.Point(17, 110);
            this.StrangerPersonalAccountButton.Name = "StrangerPersonalAccountButton";
            this.StrangerPersonalAccountButton.Size = new System.Drawing.Size(167, 67);
            this.StrangerPersonalAccountButton.TabIndex = 7;
            this.StrangerPersonalAccountButton.Text = "Посмотреть Личный профиль другого Сотрудника";
            this.StrangerPersonalAccountButton.UseVisualStyleBackColor = false;
            this.StrangerPersonalAccountButton.Click += new System.EventHandler(this.StrangerPersonalAccountButton_Click);
            // 
            // RedactionButton
            // 
            this.RedactionButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.RedactionButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.RedactionButton.FlatAppearance.BorderSize = 0;
            this.RedactionButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RedactionButton.Font = new System.Drawing.Font("Montserrat", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RedactionButton.ForeColor = System.Drawing.Color.White;
            this.RedactionButton.Location = new System.Drawing.Point(17, 29);
            this.RedactionButton.Name = "RedactionButton";
            this.RedactionButton.Size = new System.Drawing.Size(167, 51);
            this.RedactionButton.TabIndex = 5;
            this.RedactionButton.Text = "Редактировать свой профиль";
            this.RedactionButton.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(34)))), ((int)(((byte)(50)))));
            this.label3.Location = new System.Drawing.Point(408, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 27);
            this.label3.TabIndex = 10;
            this.label3.Text = "ФИО";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(34)))), ((int)(((byte)(50)))));
            this.label1.Location = new System.Drawing.Point(408, 188);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(196, 27);
            this.label1.TabIndex = 12;
            this.label1.Text = "Номер телефона";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(34)))), ((int)(((byte)(50)))));
            this.label2.Location = new System.Drawing.Point(408, 263);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 27);
            this.label2.TabIndex = 14;
            this.label2.Text = "Email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(34)))), ((int)(((byte)(50)))));
            this.label4.Location = new System.Drawing.Point(408, 338);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(329, 27);
            this.label4.TabIndex = 16;
            this.label4.Text = "Бронирование рабочих мест";
            // 
            // ChangeButton
            // 
            this.ChangeButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.ChangeButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ChangeButton.FlatAppearance.BorderSize = 0;
            this.ChangeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChangeButton.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChangeButton.ForeColor = System.Drawing.Color.White;
            this.ChangeButton.Location = new System.Drawing.Point(366, 433);
            this.ChangeButton.Name = "ChangeButton";
            this.ChangeButton.Size = new System.Drawing.Size(301, 38);
            this.ChangeButton.TabIndex = 17;
            this.ChangeButton.Text = "Изменить данные";
            this.ChangeButton.UseVisualStyleBackColor = false;
            this.ChangeButton.Click += new System.EventHandler(this.ChangeButton_Click);
            // 
            // AvatarProfil
            // 
            this.AvatarProfil.BackColor = System.Drawing.Color.White;
            this.AvatarProfil.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AvatarProfil.Location = new System.Drawing.Point(234, 146);
            this.AvatarProfil.Name = "AvatarProfil";
            this.AvatarProfil.Size = new System.Drawing.Size(145, 120);
            this.AvatarProfil.TabIndex = 5;
            this.AvatarProfil.TabStop = false;
            this.AvatarProfil.Click += new System.EventHandler(this.AvatarProfil_Click);
            // 
            // HeaderLogo
            // 
            this.HeaderLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.HeaderLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.HeaderLogo.Image = global::Parma_Project.Properties.Resources.PARMA_TG_logo_с_охранным_полем_01;
            this.HeaderLogo.Location = new System.Drawing.Point(0, 0);
            this.HeaderLogo.Name = "HeaderLogo";
            this.HeaderLogo.Size = new System.Drawing.Size(1006, 103);
            this.HeaderLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.HeaderLogo.TabIndex = 1;
            this.HeaderLogo.TabStop = false;
            this.HeaderLogo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.HeaderLogo_MouseDown_1);
            this.HeaderLogo.MouseMove += new System.Windows.Forms.MouseEventHandler(this.HeaderLogo_MouseMove_1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(413, 146);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 16);
            this.label5.TabIndex = 18;
            // 
            // ChangePhotoButton
            // 
            this.ChangePhotoButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.ChangePhotoButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ChangePhotoButton.FlatAppearance.BorderSize = 0;
            this.ChangePhotoButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChangePhotoButton.Font = new System.Drawing.Font("Montserrat", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChangePhotoButton.ForeColor = System.Drawing.Color.White;
            this.ChangePhotoButton.Location = new System.Drawing.Point(234, 274);
            this.ChangePhotoButton.Name = "ChangePhotoButton";
            this.ChangePhotoButton.Size = new System.Drawing.Size(145, 30);
            this.ChangePhotoButton.TabIndex = 8;
            this.ChangePhotoButton.Text = "Изменить фото";
            this.ChangePhotoButton.UseVisualStyleBackColor = false;
            this.ChangePhotoButton.Click += new System.EventHandler(this.ChangePhotoButton_Click);
            // 
            // UploadBookingButton
            // 
            this.UploadBookingButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.UploadBookingButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.UploadBookingButton.FlatAppearance.BorderSize = 0;
            this.UploadBookingButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UploadBookingButton.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.UploadBookingButton.ForeColor = System.Drawing.Color.White;
            this.UploadBookingButton.Location = new System.Drawing.Point(416, 366);
            this.UploadBookingButton.Name = "UploadBookingButton";
            this.UploadBookingButton.Size = new System.Drawing.Size(492, 35);
            this.UploadBookingButton.TabIndex = 28;
            this.UploadBookingButton.Text = "Выгрузить свою историю бронирования";
            this.UploadBookingButton.UseVisualStyleBackColor = false;
            this.UploadBookingButton.Click += new System.EventHandler(this.UploadBookingButton_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Montserrat", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(26, 480);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(394, 18);
            this.label6.TabIndex = 29;
            this.label6.Text = "Для просмотра фотографии кликните на прямоугольник";
            // 
            // PersonalAccountEmlpoyee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(236)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(1006, 507);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.UploadBookingButton);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ChangeButton);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ChangePhotoButton);
            this.Controls.Add(this.AvatarProfil);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.MapButton);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.HeaderLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "PersonalAccountEmlpoyee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PersonalAccountEmlpoyee";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PersonalAccountEmlpoyeeRedaction_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PersonalAccountEmlpoyeeRedaction_MouseMove);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AvatarProfil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HeaderLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox HeaderLogo;
        private System.Windows.Forms.Label CloseButton;
        private System.Windows.Forms.Button MapButton;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button StrangerPersonalAccountButton;
        private System.Windows.Forms.Button RedactionButton;
        private System.Windows.Forms.PictureBox AvatarProfil;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button ChangeButton;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button ChangePhotoButton;
        private System.Windows.Forms.Button UploadBookingButton;
        private System.Windows.Forms.Label label6;
    }
}