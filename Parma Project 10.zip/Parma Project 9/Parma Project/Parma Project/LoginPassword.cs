﻿using MySql;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parma_Project
{
    public partial class LoginPassword : Form
    { 
        public LoginPassword() //конструктор
        {
            InitializeComponent();
        }


        //ВОЗМОЖНОСТЬ ПЕРЕДВИЖЕНИЯ ОКНА ПРОГРАММЫ
        Point lastPoint; //точка последнего местоположения мыши
        private void LoginPassword_MouseMove(object sender, MouseEventArgs e) //передвижение приложения при зажатой левой мыши за серую часть
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void LoginPassword_MouseDown(object sender, MouseEventArgs e) //определение последнего местоположения мыши на серой части
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void HeaderLogo_MouseMove(object sender, MouseEventArgs e) //передвижение приложения при зажатой левой мыши за синюю часть
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void HeaderLogo_MouseDown(object sender, MouseEventArgs e) //определение последнего местоположения мыши на синей части
        {
            lastPoint = new Point(e.X, e.Y);
        }

        //НАЖАТИЕ ВСЕХ ВОЗМОЖНЫХ КНОПОК
        private void CloseButton_Click(object sender, EventArgs e) //кнопка Х (закрыть программы)
        {
            this.Close();
            Application.Exit();
        }

        private async void EnterButton_Click(object sender, EventArgs e) //кнопка Войти
        {
            try
            {
                String logUser = LoginInput.Text;
                String pasUser = PasswordInput.Text;

                //String IDUser = ID;

                DB db = new DB();
                DataTable table = new DataTable();
                MySqlDataAdapter adapter = new MySqlDataAdapter();

                db.openConnection();
                MySqlCommand command = new MySqlCommand("SELECT * FROM `users` WHERE `login` = @usLog AND `password` = @usPas", db.getConnection()); //команда к MySQL, выборка всех записей из таблицы/бд, это и есть условие
                command.Parameters.Add("@usLog", MySqlDbType.VarChar).Value = logUser;
                command.Parameters.Add("@usPas", MySqlDbType.VarChar).Value = pasUser;

                adapter.SelectCommand = command;
                adapter.Fill(table);

                db.closeConnection();

                //проверка на ввод через бд
                if (table.Rows.Count > 0) //если ввод верный
                {
                    db.openConnection();
                    string IdBox;
                    command = new MySqlCommand("SELECT id FROM `users` WHERE `login` = @usID", db.getConnection());
                    command.Parameters.Add("@usID", MySqlDbType.VarChar).Value = logUser;
                    IdBox = command.ExecuteScalar().ToString(); //айдишник сотрудника/админа
                    db.closeConnection();
                    db.openConnection();
                    command = new MySqlCommand("SELECT type FROM `users` WHERE `login` = @usID", db.getConnection());
                    command.Parameters.Add("@usID", MySqlDbType.VarChar).Value = logUser;

                    if (Convert.ToInt32(command.ExecuteScalar()) == 2) //если Сотрудник
                    {
                        OfficeMap1 officeMap1 = new OfficeMap1(IdBox);
                        officeMap1.Show();
                        this.Hide();
                    }
                    else //если Администратор
                    {
                        PersonalAccountAdmin.FunctionsAdmin admin = new PersonalAccountAdmin.FunctionsAdmin();
                        admin.Show();
                        this.Hide();
                    }
                    db.closeConnection();
                }
                else
                    MessageBox.Show("Вы не авторизованы."); //пользователь не авторизован
                //если ввод неверный, то повторная попытка ввода
            }
            catch
            {
                MessageBox.Show("Ошибка при открытии базы данных.");
                this.Close();
                Application.Exit();
            }
        }

        private void LoginInput_TextChanged(object sender, EventArgs e) //поле ввода логина
        {
            
        }

        private void PasswordInput_TextChanged(object sender, EventArgs e) //поле ввода пароля
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
