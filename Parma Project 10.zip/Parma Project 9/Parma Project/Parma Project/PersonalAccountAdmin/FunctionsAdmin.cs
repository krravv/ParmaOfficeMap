﻿using Microsoft.Office.Interop.Excel;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;


namespace Parma_Project.PersonalAccountAdmin
{
    public partial class FunctionsAdmin : Form
    {
        public FunctionsAdmin()
        {
            InitializeComponent();
        }
        //ВОЗМОЖНОСТЬ ПЕРЕДВИЖЕНИЯ ОКНА ПРОГРАММЫ
        System.Drawing.Point lastPoint; //точка последнего местоположения мыши
        private void PersonalAccountAdmin_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void PersonalAccountAdmin_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new System.Drawing.Point(e.X, e.Y);
        }

        private void HeaderLogo_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void HeaderLogo_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new System.Drawing.Point(e.X, e.Y);
        }

        private void NewEmployeeButton_Click(object sender, EventArgs e)
        {
            NewEmployee newEmployee = new NewEmployee();
            newEmployee.Show();
            this.Close();
        }

        private void EnterToAccButton_Click(object sender, EventArgs e)
        {
            SearchEmployeeAdmin search = new SearchEmployeeAdmin();
            search.Show();
            this.Close();
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
            System.Windows.Forms.Application.Exit();
        }

        private void BookingButton_Click(object sender, EventArgs e)
        {
            Excel.Application xlApp = new Excel.Application();
            Excel.Worksheet xlSheet;
            Excel.Range xlSheetRange;
            try
            {
                xlApp.Workbooks.Add(Type.Missing);
                xlApp.Interactive = false;
                xlApp.EnableEvents = false;
                xlSheet = (Excel.Worksheet)xlApp.Sheets[1];
                xlSheet.Name = "История бронирования";
                System.Data.DataTable dt = GetData();

                int collInd = 0, rowInd = 0;
                string data = " ";

                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    data = dt.Columns[i].ColumnName.ToString();
                    switch (data)
                    {
                        case "id table": data = "Рабочее место"; break;
                        case "period1": data = "Начало брони"; break;
                        case "period2": data = "Конец брони"; break;
                        case "id employee": data = "Сотрудник"; break;
                    }
                    xlSheet.Cells[1, i + 1] = data;
                    xlSheet.StandardWidth = data.Length + 2;
                    xlSheetRange = xlSheet.get_Range("A1:D1");
                    xlSheetRange.WrapText = true;
                    xlSheetRange.Font.Bold = true;
                    releaseObject(xlSheetRange);
                }
                for (rowInd = 0; rowInd < dt.Rows.Count; rowInd++)
                {
                    for (collInd = 0; collInd < dt.Columns.Count; collInd++)
                    {
                        data = dt.Rows[rowInd].ItemArray[collInd].ToString();
                        xlSheet.Cells[rowInd + 2, collInd + 1] = data;
                    }
                }
                releaseObject(xlSheet);
            }
            catch
            {
                MessageBox.Show("Ошибка при заполнении Excel.");
            }
            finally
            {
                xlApp.Visible = true;
                xlApp.Interactive = true;
                xlApp.ScreenUpdating = true;
                xlApp.UserControl = true;
                releaseObject(xlApp);
            }
        }
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show(ex.ToString(), "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            finally
            {
                GC.Collect();
            }
        }
        private System.Data.DataTable GetData()
        {
            DB db = new DB();
            System.Data.DataTable dt = new System.Data.DataTable();
            try
            {
                db.openConnection();
                MySqlCommand command = new MySqlCommand("SELECT * FROM `booking history`", db.getConnection());
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dt = ds.Tables[0];
            }
            catch
            {
                MessageBox.Show("Ошибка при открытии базы данных.");
            }
            finally
            {
                db.closeConnection();
            }
            return dt;
        }
    }
}