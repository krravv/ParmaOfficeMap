﻿namespace Parma_Project.PersonalAccountAdmin
{
    partial class FunctionsAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CloseButton = new System.Windows.Forms.Label();
            this.HeaderLogo = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.EnterToAccButton = new System.Windows.Forms.Button();
            this.NewEmployeeButton = new System.Windows.Forms.Button();
            this.BookingButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.HeaderLogo)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CloseButton
            // 
            this.CloseButton.AutoSize = true;
            this.CloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.CloseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CloseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CloseButton.ForeColor = System.Drawing.Color.White;
            this.CloseButton.Location = new System.Drawing.Point(976, 0);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(30, 29);
            this.CloseButton.TabIndex = 3;
            this.CloseButton.Text = "X";
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // HeaderLogo
            // 
            this.HeaderLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.HeaderLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.HeaderLogo.Image = global::Parma_Project.Properties.Resources.PARMA_TG_logo_с_охранным_полем_01;
            this.HeaderLogo.Location = new System.Drawing.Point(0, 0);
            this.HeaderLogo.Name = "HeaderLogo";
            this.HeaderLogo.Size = new System.Drawing.Size(1006, 103);
            this.HeaderLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.HeaderLogo.TabIndex = 2;
            this.HeaderLogo.TabStop = false;
            this.HeaderLogo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.HeaderLogo_MouseDown);
            this.HeaderLogo.MouseMove += new System.Windows.Forms.MouseEventHandler(this.HeaderLogo_MouseMove);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.BookingButton);
            this.panel1.Controls.Add(this.EnterToAccButton);
            this.panel1.Controls.Add(this.NewEmployeeButton);
            this.panel1.Location = new System.Drawing.Point(150, 142);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(719, 306);
            this.panel1.TabIndex = 5;
            // 
            // EnterToAccButton
            // 
            this.EnterToAccButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.EnterToAccButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.EnterToAccButton.FlatAppearance.BorderSize = 0;
            this.EnterToAccButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EnterToAccButton.Font = new System.Drawing.Font("Montserrat", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.EnterToAccButton.ForeColor = System.Drawing.Color.White;
            this.EnterToAccButton.Location = new System.Drawing.Point(433, 30);
            this.EnterToAccButton.Name = "EnterToAccButton";
            this.EnterToAccButton.Size = new System.Drawing.Size(239, 106);
            this.EnterToAccButton.TabIndex = 6;
            this.EnterToAccButton.Text = "Войти в ЛК Сотрудника";
            this.EnterToAccButton.UseVisualStyleBackColor = false;
            this.EnterToAccButton.Click += new System.EventHandler(this.EnterToAccButton_Click);
            // 
            // NewEmployeeButton
            // 
            this.NewEmployeeButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.NewEmployeeButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.NewEmployeeButton.FlatAppearance.BorderSize = 0;
            this.NewEmployeeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewEmployeeButton.Font = new System.Drawing.Font("Montserrat", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NewEmployeeButton.ForeColor = System.Drawing.Color.White;
            this.NewEmployeeButton.Location = new System.Drawing.Point(47, 30);
            this.NewEmployeeButton.Name = "NewEmployeeButton";
            this.NewEmployeeButton.Size = new System.Drawing.Size(239, 106);
            this.NewEmployeeButton.TabIndex = 5;
            this.NewEmployeeButton.Text = "Добавить нового Сотрудника";
            this.NewEmployeeButton.UseVisualStyleBackColor = false;
            this.NewEmployeeButton.Click += new System.EventHandler(this.NewEmployeeButton_Click);
            // 
            // BookingButton
            // 
            this.BookingButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.BookingButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.BookingButton.FlatAppearance.BorderSize = 0;
            this.BookingButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BookingButton.Font = new System.Drawing.Font("Montserrat", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BookingButton.ForeColor = System.Drawing.Color.White;
            this.BookingButton.Location = new System.Drawing.Point(221, 174);
            this.BookingButton.Name = "BookingButton";
            this.BookingButton.Size = new System.Drawing.Size(275, 106);
            this.BookingButton.TabIndex = 7;
            this.BookingButton.Text = "Выгрузить историю бронирования";
            this.BookingButton.UseVisualStyleBackColor = false;
            this.BookingButton.Click += new System.EventHandler(this.BookingButton_Click);
            // 
            // FunctionsAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1006, 507);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.HeaderLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FunctionsAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PersonalAccountAdmin";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.PersonalAccountAdmin_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PersonalAccountAdmin_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.HeaderLogo)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label CloseButton;
        private System.Windows.Forms.PictureBox HeaderLogo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button EnterToAccButton;
        private System.Windows.Forms.Button NewEmployeeButton;
        private System.Windows.Forms.Button BookingButton;
    }
}