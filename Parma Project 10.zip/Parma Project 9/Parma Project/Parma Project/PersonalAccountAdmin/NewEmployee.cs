﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Parma_Project.PersonalAccountAdmin
{
    public partial class NewEmployee : Form
    {
        public NewEmployee()
        {
            InitializeComponent();
        }

        private void AddEmployeeButton_Click(object sender, EventArgs e)
        {
            String FIOUser = FIOInput.Text;
            String EmailUser = EmailInput.Text;
            String PhoneUser = PhoneInput.Text;
            String Place = "";

            //автоматическое задание логина и пароля
            try
            {
                string[] temp = FIOUser.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                //if (PhoneUser.Length != 10 || temp.Length != 3 || EmailUser.ToCharArray().Contains('@')) throw new Exception();
                String LoginUser = temp[0] + "-" + temp[1][0] + temp[2][0]; //логин
                String PasswordUser = ""; //пароль

                Random random = new Random();
                int countsymb = random.Next(6, 10);
                while (countsymb > 0)
                {
                    PasswordUser += (Convert.ToChar(random.Next(48, 58))).ToString();
                    PasswordUser += (Convert.ToChar(random.Next(65, 91))).ToString();
                    PasswordUser += (Convert.ToChar(random.Next(97, 123))).ToString();
                    countsymb -= 3;
                }

                //добавление нового пользователя в базу данных
                try
                {
                    DB db = new DB();

                    DataTable table = new DataTable();

                    db.openConnection();

                    MySqlCommand command = new MySqlCommand("INSERT INTO `users`(`login`, `password`, `FIO`, `email`, `phone`, `type`, `photo`) VALUES (@usLogin, @usPass, @usFIO, @usEmail, @usPhone, 2, @link)", db.getConnection());
                    command.Parameters.Add("@usLogin", MySqlDbType.VarChar).Value = LoginUser;
                    command.Parameters.Add("@usPass", MySqlDbType.VarChar).Value = PasswordUser;
                    command.Parameters.Add("@usFIO", MySqlDbType.VarChar).Value = FIOUser;
                    command.Parameters.Add("@usEmail", MySqlDbType.VarChar).Value = EmailUser;
                    command.Parameters.Add("@usPhone", MySqlDbType.VarChar).Value = PhoneUser;
                    command.Parameters.Add("@link", MySqlDbType.VarChar).Value = "";

                    command.ExecuteNonQuery();
                    db.closeConnection();

                    db.openConnection();
                    command = new MySqlCommand("SELECT id FROM `users` WHERE FIO = @usFIO", db.getConnection());
                    command.Parameters.Add("@usFIO", MySqlDbType.VarChar).Value = FIOUser;
                    string id = command.ExecuteScalar().ToString();
                    db.closeConnection();

                    MessageBox.Show("Новый пользователь добавлен в базу данных." +
                        //$"\nID нового сотрудника: {id}" +
                        $"\nЛогин и пароль созданы автоматически." +
                        $"\nЛогин: {LoginUser}\nПароль: {PasswordUser}\n");
                }
                catch
                {
                    MessageBox.Show("Ошибка при добавлении нового пользователя.");
                }
            }
            catch
            {
                MessageBox.Show("Ошибка при вводе данных.");
            }

            PersonalAccountAdmin.FunctionsAdmin functions = new PersonalAccountAdmin.FunctionsAdmin();
            functions.Show();
            this.Close();
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }
        //ВОЗМОЖНОСТЬ ПЕРЕДВИЖЕНИЯ ОКНА ПРОГРАММЫ
        Point lastPoint; //точка последнего местоположения мыши
        private void NewEmployee_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void NewEmployee_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void HeaderLogo_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void HeaderLogo_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void FunctionsAdminButton_Click(object sender, EventArgs e)
        {
            FunctionsAdmin functionsAdmin = new FunctionsAdmin();
            functionsAdmin.Show();
            this.Close();
        }

        private void FIOInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void NewEmployee_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
