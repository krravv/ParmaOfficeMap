﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parma_Project.PersonalAccountAdmin
{
    public partial class SearchEmployeeAdmin : Form
    {
        String IDUser = "";
        public SearchEmployeeAdmin()
        {
            InitializeComponent();
        }
        public SearchEmployeeAdmin(String ID)
        {
            this.IDUser = ID;
            InitializeComponent();
        }
        //ВОЗМОЖНОСТЬ ПЕРЕДВИЖЕНИЯ ОКНА ПРОГРАММЫ
        Point lastPoint; //точка последнего местоположения мыши
        private void SearchEmployee_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void SearchEmployee_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void HeaderLogo_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void HeaderLogo_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            try
            {
                int.Parse(IDInput.Text);
                IDUser = IDInput.Text;

                DB db = new DB();

                DataTable table = new DataTable();

                MySqlDataAdapter adapter = new MySqlDataAdapter();

                db.openConnection();
                MySqlCommand command = new MySqlCommand("SELECT type FROM `users` WHERE `ID` = @usID", db.getConnection());

                command.Parameters.Add("@usID", MySqlDbType.VarChar).Value = IDUser;


                adapter.SelectCommand = command;
                try
                {
                    adapter.Fill(table);
                }
                catch
                {
                    MessageBox.Show("Ошибка при вводе ID Сотрудника.");
                }
                db.closeConnection();
                if (table.Rows.Count > 0) //если ввод верный
                {
                    db.openConnection();
                    if (Convert.ToInt32(command.ExecuteScalar()) == 2) //если Сотрудник
                    {

                        OfficeMap1 officeMap1 = new OfficeMap1(IDUser, true);
                        officeMap1.Show();
                    }
                    else
                    {
                        MessageBox.Show("Нельзя войти в Личный кабинет Администратора.");
                        FunctionsAdmin functionsAdmin = new FunctionsAdmin();
                        functionsAdmin.Show();
                    }
                    db.closeConnection();
                    this.Close();
                }
                else
                    MessageBox.Show("Ошибка при вводе ID Сотрудника."); //пользователь не авторизован
                                                                        //если ввод неверный, то повторная попытка ввода
            }
            catch
            {
                MessageBox.Show("Ошибка при вводе ID Сотрудника.");
            }

        }

        private void FunctionsAdminButton_Click(object sender, EventArgs e)
        {
            FunctionsAdmin functionsAdmin = new FunctionsAdmin();
            functionsAdmin.Show();
            this.Close();
        }

        private void IDInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void SearchEmployeeAdmin_Load(object sender, EventArgs e)
        {

        }
    }
}
