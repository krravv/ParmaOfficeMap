﻿namespace Parma_Project.PersonalAccountAdmin
{
    partial class SearchEmployeeAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CloseButton = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SearchButton = new System.Windows.Forms.Button();
            this.IDInput = new System.Windows.Forms.TextBox();
            this.HeaderLogo = new System.Windows.Forms.PictureBox();
            this.FunctionsAdminButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.HeaderLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // CloseButton
            // 
            this.CloseButton.AutoSize = true;
            this.CloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.CloseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CloseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CloseButton.ForeColor = System.Drawing.Color.White;
            this.CloseButton.Location = new System.Drawing.Point(977, 0);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(30, 29);
            this.CloseButton.TabIndex = 6;
            this.CloseButton.Text = "X";
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(34)))), ((int)(((byte)(50)))));
            this.label4.Location = new System.Drawing.Point(348, 221);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(166, 27);
            this.label4.TabIndex = 11;
            this.label4.Text = "ID Сотрудника";
            // 
            // SearchButton
            // 
            this.SearchButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.SearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SearchButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SearchButton.Font = new System.Drawing.Font("Montserrat", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SearchButton.ForeColor = System.Drawing.Color.White;
            this.SearchButton.Location = new System.Drawing.Point(416, 313);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(184, 53);
            this.SearchButton.TabIndex = 9;
            this.SearchButton.Text = "Найти";
            this.SearchButton.UseVisualStyleBackColor = false;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // IDInput
            // 
            this.IDInput.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.IDInput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.IDInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.IDInput.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(34)))), ((int)(((byte)(50)))));
            this.IDInput.Location = new System.Drawing.Point(353, 251);
            this.IDInput.Name = "IDInput";
            this.IDInput.Size = new System.Drawing.Size(305, 30);
            this.IDInput.TabIndex = 8;
            this.IDInput.UseSystemPasswordChar = true;
            this.IDInput.TextChanged += new System.EventHandler(this.IDInput_TextChanged);
            // 
            // HeaderLogo
            // 
            this.HeaderLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.HeaderLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.HeaderLogo.Image = global::Parma_Project.Properties.Resources.PARMA_TG_logo_с_охранным_полем_01;
            this.HeaderLogo.Location = new System.Drawing.Point(0, 0);
            this.HeaderLogo.Name = "HeaderLogo";
            this.HeaderLogo.Size = new System.Drawing.Size(1006, 103);
            this.HeaderLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.HeaderLogo.TabIndex = 5;
            this.HeaderLogo.TabStop = false;
            this.HeaderLogo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.HeaderLogo_MouseDown);
            this.HeaderLogo.MouseMove += new System.Windows.Forms.MouseEventHandler(this.HeaderLogo_MouseMove);
            // 
            // FunctionsAdminButton
            // 
            this.FunctionsAdminButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.FunctionsAdminButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FunctionsAdminButton.FlatAppearance.BorderSize = 0;
            this.FunctionsAdminButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FunctionsAdminButton.Font = new System.Drawing.Font("Montserrat", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FunctionsAdminButton.ForeColor = System.Drawing.Color.White;
            this.FunctionsAdminButton.Location = new System.Drawing.Point(36, 22);
            this.FunctionsAdminButton.Name = "FunctionsAdminButton";
            this.FunctionsAdminButton.Size = new System.Drawing.Size(266, 60);
            this.FunctionsAdminButton.TabIndex = 12;
            this.FunctionsAdminButton.Text = "Вернуться в ЛК Администратора";
            this.FunctionsAdminButton.UseVisualStyleBackColor = false;
            this.FunctionsAdminButton.Click += new System.EventHandler(this.FunctionsAdminButton_Click);
            // 
            // SearchEmployeeAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(236)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(1006, 507);
            this.Controls.Add(this.FunctionsAdminButton);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.IDInput);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.HeaderLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SearchEmployeeAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SearchEmployee";
            this.Load += new System.EventHandler(this.SearchEmployeeAdmin_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.SearchEmployee_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SearchEmployee_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.HeaderLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox HeaderLogo;
        private System.Windows.Forms.Label CloseButton;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.TextBox IDInput;
        private System.Windows.Forms.Button FunctionsAdminButton;
    }
}