﻿using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;
using Parma_Project.OfficeMap;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parma_Project.Рабочие_места
{
    public partial class BookingPlace : Form
    {
        String IDUser = "";
        String IDTable = "";
        public BookingPlace(String idUser, String idTable)
        {
            this.IDUser = idUser;
            this.IDTable = idTable;

            DB db = new DB();
            MySqlDataAdapter adapter = new MySqlDataAdapter();

            db.openConnection();
            MySqlCommand command = new MySqlCommand("SELECT period2 FROM `booking` WHERE `number` = @idTable", db.getConnection()); //команда к MySQL, выборка всех записей из таблицы/бд, это и есть условие
            command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = IDTable;
            adapter.SelectCommand = command;
            string speriod2 = command.ExecuteScalar().ToString();
            db.closeConnection();

            DateTime period2;
            try
            {
                period2 = DateTime.ParseExact(speriod2, "dd.MM.yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch
            {
                period2 = DateTime.Today;
            }

            Label label = new Label();
            if (period2 < DateTime.Now) label.Text = "Выбранное место свободно";
            else label.Text = "Выбранное место будет свободно после " + period2.ToShortDateString();
            label.Location = new Point(50, 120);
            label.Font = new Font("Montserrat", 11, FontStyle.Regular);
            label.ForeColor = Color.Brown;
            label.AutoSize = true;
            Controls.Add(label);

            InitializeComponent();
        }
        private void CloseBook() //закрытие окна бронирования
        {
            this.Close();
        }
        private void NoBookButton_Click(object sender, EventArgs e) //не бронировать, вернуться к карте нужного этажа
        {
            CloseBook();
        }
        //ВОЗМОЖНОСТЬ ПЕРЕДВИЖЕНИЯ ОКНА ПРОГРАММЫ
        Point lastPoint; //точка последнего местоположения мыши

        private void BookingPlace_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void BookingPlace_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void HeaderLogo_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void HeaderLogo_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void BookButton_Click(object sender, EventArgs e) //забронировать место
        {
            DateTime date1 = Date1.Value;
            DateTime date2 = Date2.Value;

            DB db = new DB();
            MySqlDataAdapter adapter;
            db.openConnection();
            MySqlCommand command = new MySqlCommand("SELECT period1, period2 FROM `booking history` WHERE `id employee` = @idUser", db.getConnection());
            command.Parameters.Add("@idUser", MySqlDbType.VarChar).Value = this.IDUser;
            adapter = new MySqlDataAdapter(command);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            db.closeConnection();

            bool flag = false;
            System.Data.DataTable dt = new System.Data.DataTable(); dt = ds.Tables[0];
            if (dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    DateTime Period1 = DateTime.ParseExact(row[0].ToString(), "dd.MM.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    DateTime Period2 = DateTime.ParseExact(row[1].ToString(), "dd.MM.yyyy", System.Globalization.CultureInfo.InvariantCulture);

                    if (Period1 <= date1 && Period2 >= date2)
                    {
                        MessageBox.Show($"{Period1.ToShortDateString()} - {Period2.ToShortDateString()}" +
                            $"\nНа данные даты вы уже бронировали другое рабочее место.");
                        flag = true; break;
                    }
                }
            }
            if (!flag)
            {

                db.openConnection();
                command = new MySqlCommand("SELECT period1 FROM `booking` WHERE `number` = @idTable", db.getConnection()); //команда к MySQL, выборка всех записей из таблицы/бд, это и есть условие
                command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = IDTable;
                adapter.SelectCommand = command;
                string speriod1 = command.ExecuteScalar().ToString();
                db.closeConnection();

                db.openConnection();
                command = new MySqlCommand("SELECT period2 FROM `booking` WHERE `number` = @idTable", db.getConnection()); //команда к MySQL, выборка всех записей из таблицы/бд, это и есть условие
                command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = IDTable;
                adapter.SelectCommand = command;
                string speriod2 = command.ExecuteScalar().ToString();
                db.closeConnection();

                DateTime period1, period2;
                try
                {
                    period1 = DateTime.ParseExact(speriod1, "dd.MM.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    period2 = DateTime.ParseExact(speriod2, "dd.MM.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                }
                catch
                {
                    period1 = DateTime.Today; period2 = DateTime.Today;
                }

                if (period2 < date1 || period1 > date2)
                {
                    if (date2 >= date1)
                    {
                        if ((date2 - date1).TotalDays <= 14)
                        {
                            if (date1 >= DateTime.Today)
                                BookingTable(date1, date2);
                            else MessageBox.Show("Бронировать рабочее место можно, начиная с сегодняшнего дня.");
                        }
                        else MessageBox.Show("Бронировать место на срок более двух неделей запрещено.");
                    }
                    else MessageBox.Show("Срок бронирования указан некорректно.");
                }
                else MessageBox.Show("На данные даты выбранное рабочее место занято.");
            }
        }
        private void BookingTable(DateTime date1, DateTime date2)
        {
            DB db = new DB();
            MySqlDataAdapter adapter = new MySqlDataAdapter();

            db.openConnection();
            MySqlCommand command = new MySqlCommand("INSERT INTO `booking history`(`id table`, `period1`, `period2`, `id employee`) VALUES (@idTable, @date1, @date2, @idUser)", db.getConnection()); //команда к MySQL, выборка всех записей из таблицы/бд, это и есть условие
            command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = IDTable;
            command.Parameters.Add("@date1", MySqlDbType.VarChar).Value = date1.ToShortDateString();
            command.Parameters.Add("@date2", MySqlDbType.VarChar).Value = date2.ToShortDateString();
            command.Parameters.Add("@idUser", MySqlDbType.VarChar).Value = IDUser;
            command.ExecuteNonQuery();
            db.closeConnection();

            string place = "";
            if (int.Parse(IDTable) <= 10) place += "1 этаже №" + IDTable;
            else
            {
                if (int.Parse(IDTable) <= 20) place += "2 этаже №" + IDTable.Substring(1);
                if (int.Parse(IDTable) <= 30 && int.Parse(IDTable) > 20)
                    place += "3 этаже №" + IDTable.Substring(1);
            }

            MessageBox.Show("Вы забронировали место на " + place + " с " + date1.ToShortDateString() + " до " + date2.ToShortDateString());
            CloseBook();
        }
    }
}
