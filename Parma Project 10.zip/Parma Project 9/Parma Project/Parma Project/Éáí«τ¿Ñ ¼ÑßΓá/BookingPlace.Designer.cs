﻿namespace Parma_Project.Рабочие_места
{
    partial class BookingPlace
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NoBookButton = new System.Windows.Forms.Button();
            this.HeaderLogo = new System.Windows.Forms.PictureBox();
            this.BookButton = new System.Windows.Forms.Button();
            this.Date1 = new System.Windows.Forms.DateTimePicker();
            this.Date2 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.HeaderLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // NoBookButton
            // 
            this.NoBookButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.NoBookButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NoBookButton.FlatAppearance.BorderSize = 0;
            this.NoBookButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NoBookButton.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NoBookButton.ForeColor = System.Drawing.Color.White;
            this.NoBookButton.Location = new System.Drawing.Point(682, 37);
            this.NoBookButton.Name = "NoBookButton";
            this.NoBookButton.Size = new System.Drawing.Size(255, 38);
            this.NoBookButton.TabIndex = 10;
            this.NoBookButton.Text = "Не бронировать";
            this.NoBookButton.UseVisualStyleBackColor = false;
            this.NoBookButton.Click += new System.EventHandler(this.NoBookButton_Click);
            // 
            // HeaderLogo
            // 
            this.HeaderLogo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.HeaderLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.HeaderLogo.Image = global::Parma_Project.Properties.Resources.PARMA_TG_logo_с_охранным_полем_01;
            this.HeaderLogo.Location = new System.Drawing.Point(0, 0);
            this.HeaderLogo.Name = "HeaderLogo";
            this.HeaderLogo.Size = new System.Drawing.Size(1006, 103);
            this.HeaderLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.HeaderLogo.TabIndex = 8;
            this.HeaderLogo.TabStop = false;
            this.HeaderLogo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.HeaderLogo_MouseDown);
            this.HeaderLogo.MouseMove += new System.Windows.Forms.MouseEventHandler(this.HeaderLogo_MouseMove);
            // 
            // BookButton
            // 
            this.BookButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.BookButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BookButton.FlatAppearance.BorderSize = 0;
            this.BookButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BookButton.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BookButton.ForeColor = System.Drawing.Color.White;
            this.BookButton.Location = new System.Drawing.Point(376, 375);
            this.BookButton.Name = "BookButton";
            this.BookButton.Size = new System.Drawing.Size(255, 38);
            this.BookButton.TabIndex = 11;
            this.BookButton.Text = "Забронировать";
            this.BookButton.UseVisualStyleBackColor = false;
            this.BookButton.Click += new System.EventHandler(this.BookButton_Click);
            // 
            // Date1
            // 
            this.Date1.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Date1.Location = new System.Drawing.Point(376, 191);
            this.Date1.Name = "Date1";
            this.Date1.Size = new System.Drawing.Size(255, 32);
            this.Date1.TabIndex = 12;
            // 
            // Date2
            // 
            this.Date2.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Date2.Location = new System.Drawing.Point(376, 279);
            this.Date2.Name = "Date2";
            this.Date2.Size = new System.Drawing.Size(255, 32);
            this.Date2.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(373, 154);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 27);
            this.label1.TabIndex = 14;
            this.label1.Text = "С какого числа";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(373, 249);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(185, 27);
            this.label2.TabIndex = 15;
            this.label2.Text = "До какого числа";
            // 
            // BookingPlace
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1006, 507);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Date2);
            this.Controls.Add(this.Date1);
            this.Controls.Add(this.BookButton);
            this.Controls.Add(this.NoBookButton);
            this.Controls.Add(this.HeaderLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BookingPlace";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BookingPlace";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.BookingPlace_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.BookingPlace_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.HeaderLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button NoBookButton;
        private System.Windows.Forms.PictureBox HeaderLogo;
        private System.Windows.Forms.Button BookButton;
        private System.Windows.Forms.DateTimePicker Date1;
        private System.Windows.Forms.DateTimePicker Date2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}