﻿using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parma_Project
{
    public partial class OccupiedPlace : Form
    {
        String IDTable = "";
        public OccupiedPlace(String id)
        {
            this.IDTable = id;

            DB db = new DB();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable table = new DataTable();

            db.openConnection();
            MySqlCommand command = new MySqlCommand("SELECT type FROM `booking` WHERE `number` = @idTable", db.getConnection());
            command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = this.IDTable;
            if (Convert.ToInt32(command.ExecuteScalar()) == 2)
            {
                db.openConnection();
                command = new MySqlCommand("SELECT * FROM `booking` WHERE `number` = @idTable", db.getConnection());
                command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = this.IDTable;
                adapter.SelectCommand = command;
                adapter.Fill(table);
                db.closeConnection();

                string period1 = "", period2 = "", idUser = "";
                foreach (DataRow row in table.Rows)
                {
                    period1 = row[3].ToString(); period2 = row[4].ToString();
                    idUser = row[5].ToString();
                }

                db.openConnection();
                command = new MySqlCommand("SELECT FIO FROM `users` WHERE `id` = @idUser", db.getConnection());
                command.Parameters.Add("@idUser", MySqlDbType.VarChar).Value = idUser;
                string FIO = command.ExecuteScalar().ToString();
                db.closeConnection();

                string period = period1 + " - " + period2;

                Label User = new Label();
                User.Location = new Point(12, 123);
                User.Font = new Font("Montserrat", 10, FontStyle.Regular);
                User.AutoSize = true;
                User.Text = FIO;
                User.ForeColor = Color.White;
                Controls.Add(User);

                Label Date = new Label();
                Date.Location = new Point(12, 215);
                Date.Font = new Font("Montserrat", 10, FontStyle.Regular);
                Date.AutoSize = true;
                Date.Text = period;
                Date.ForeColor = Color.White;
                Controls.Add(Date);
            }
            

            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
