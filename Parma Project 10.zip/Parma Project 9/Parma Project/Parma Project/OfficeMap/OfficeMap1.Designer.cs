﻿namespace Parma_Project
{
    partial class OfficeMap1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PerAccRedButton = new System.Windows.Forms.Button();
            this.CloseButton = new System.Windows.Forms.Label();
            this.HeaderLogo = new System.Windows.Forms.PictureBox();
            this.floor1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.floop3 = new System.Windows.Forms.Button();
            this.floop2 = new System.Windows.Forms.Button();
            this.Table11 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Table14 = new System.Windows.Forms.Button();
            this.Table12 = new System.Windows.Forms.Button();
            this.Table13 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Table18 = new System.Windows.Forms.Button();
            this.Table17 = new System.Windows.Forms.Button();
            this.Table16 = new System.Windows.Forms.Button();
            this.Table15 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Table110 = new System.Windows.Forms.Button();
            this.Table19 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HeaderLogo)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.PerAccRedButton);
            this.panel1.Controls.Add(this.CloseButton);
            this.panel1.Controls.Add(this.HeaderLogo);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1006, 103);
            this.panel1.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Image = global::Parma_Project.Properties.Resources.PARMA_TG_logo_с_охранным_полем_01;
            this.pictureBox1.Location = new System.Drawing.Point(0, 103);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1006, 103);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // PerAccRedButton
            // 
            this.PerAccRedButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.PerAccRedButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PerAccRedButton.FlatAppearance.BorderSize = 0;
            this.PerAccRedButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PerAccRedButton.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PerAccRedButton.ForeColor = System.Drawing.Color.White;
            this.PerAccRedButton.Location = new System.Drawing.Point(628, 29);
            this.PerAccRedButton.Name = "PerAccRedButton";
            this.PerAccRedButton.Size = new System.Drawing.Size(342, 38);
            this.PerAccRedButton.TabIndex = 7;
            this.PerAccRedButton.Text = "Перейти в Личный кабинет";
            this.PerAccRedButton.UseVisualStyleBackColor = false;
            this.PerAccRedButton.Click += new System.EventHandler(this.PerAccRedButton_Click);
            // 
            // CloseButton
            // 
            this.CloseButton.AutoSize = true;
            this.CloseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CloseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CloseButton.ForeColor = System.Drawing.Color.White;
            this.CloseButton.Location = new System.Drawing.Point(975, 0);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(30, 29);
            this.CloseButton.TabIndex = 1;
            this.CloseButton.Text = "X";
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // HeaderLogo
            // 
            this.HeaderLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.HeaderLogo.Image = global::Parma_Project.Properties.Resources.PARMA_TG_logo_с_охранным_полем_01;
            this.HeaderLogo.Location = new System.Drawing.Point(0, 0);
            this.HeaderLogo.Name = "HeaderLogo";
            this.HeaderLogo.Size = new System.Drawing.Size(1006, 103);
            this.HeaderLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.HeaderLogo.TabIndex = 0;
            this.HeaderLogo.TabStop = false;
            this.HeaderLogo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.HeaderLogo_MouseDown);
            this.HeaderLogo.MouseMove += new System.Windows.Forms.MouseEventHandler(this.HeaderLogo_MouseMove);
            // 
            // floor1
            // 
            this.floor1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.floor1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.floor1.FlatAppearance.BorderSize = 0;
            this.floor1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.floor1.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.floor1.ForeColor = System.Drawing.Color.White;
            this.floor1.Location = new System.Drawing.Point(17, 20);
            this.floor1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.floor1.Name = "floor1";
            this.floor1.Size = new System.Drawing.Size(117, 58);
            this.floor1.TabIndex = 7;
            this.floor1.Text = "1 этаж";
            this.floor1.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.floop3);
            this.panel2.Controls.Add(this.floop2);
            this.panel2.Controls.Add(this.floor1);
            this.panel2.Location = new System.Drawing.Point(22, 121);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(152, 242);
            this.panel2.TabIndex = 8;
            // 
            // floop3
            // 
            this.floop3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.floop3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.floop3.FlatAppearance.BorderSize = 0;
            this.floop3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.floop3.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.floop3.ForeColor = System.Drawing.Color.White;
            this.floop3.Location = new System.Drawing.Point(17, 161);
            this.floop3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.floop3.Name = "floop3";
            this.floop3.Size = new System.Drawing.Size(117, 58);
            this.floop3.TabIndex = 9;
            this.floop3.Text = "3 этаж";
            this.floop3.UseVisualStyleBackColor = false;
            this.floop3.Click += new System.EventHandler(this.floop3_Click);
            // 
            // floop2
            // 
            this.floop2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.floop2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.floop2.FlatAppearance.BorderSize = 0;
            this.floop2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.floop2.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.floop2.ForeColor = System.Drawing.Color.White;
            this.floop2.Location = new System.Drawing.Point(17, 90);
            this.floop2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.floop2.Name = "floop2";
            this.floop2.Size = new System.Drawing.Size(117, 58);
            this.floop2.TabIndex = 8;
            this.floop2.Text = "2 этаж";
            this.floop2.UseVisualStyleBackColor = false;
            this.floop2.Click += new System.EventHandler(this.floop2_Click);
            // 
            // Table11
            // 
            this.Table11.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Table11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Table11.Location = new System.Drawing.Point(26, 22);
            this.Table11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table11.Name = "Table11";
            this.Table11.Size = new System.Drawing.Size(94, 66);
            this.Table11.TabIndex = 9;
            this.Table11.UseVisualStyleBackColor = false;
            this.Table11.Click += new System.EventHandler(this.Table11_Click);
            this.Table11.MouseEnter += new System.EventHandler(this.Table11_MouseEnter);
            this.Table11.MouseLeave += new System.EventHandler(this.Table11_MouseLeave);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.panel3.Controls.Add(this.Table14);
            this.panel3.Controls.Add(this.Table12);
            this.panel3.Controls.Add(this.Table13);
            this.panel3.Controls.Add(this.Table11);
            this.panel3.Location = new System.Drawing.Point(196, 121);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(270, 366);
            this.panel3.TabIndex = 10;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // Table14
            // 
            this.Table14.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table14.Location = new System.Drawing.Point(158, 259);
            this.Table14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table14.Name = "Table14";
            this.Table14.Size = new System.Drawing.Size(94, 66);
            this.Table14.TabIndex = 20;
            this.Table14.UseVisualStyleBackColor = false;
            this.Table14.Click += new System.EventHandler(this.Table14_Click);
            this.Table14.MouseEnter += new System.EventHandler(this.Table14_MouseEnter);
            this.Table14.MouseLeave += new System.EventHandler(this.Table14_MouseLeave);
            // 
            // Table12
            // 
            this.Table12.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Table12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Table12.Location = new System.Drawing.Point(158, 104);
            this.Table12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table12.Name = "Table12";
            this.Table12.Size = new System.Drawing.Size(94, 66);
            this.Table12.TabIndex = 18;
            this.Table12.UseVisualStyleBackColor = false;
            this.Table12.Click += new System.EventHandler(this.Table12_Click);
            this.Table12.MouseEnter += new System.EventHandler(this.Table12_MouseEnter);
            this.Table12.MouseLeave += new System.EventHandler(this.Table12_MouseLeave);
            // 
            // Table13
            // 
            this.Table13.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table13.Location = new System.Drawing.Point(26, 176);
            this.Table13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table13.Name = "Table13";
            this.Table13.Size = new System.Drawing.Size(94, 66);
            this.Table13.TabIndex = 12;
            this.Table13.UseVisualStyleBackColor = false;
            this.Table13.Click += new System.EventHandler(this.Table13_Click);
            this.Table13.MouseEnter += new System.EventHandler(this.Table13_MouseEnter);
            this.Table13.MouseLeave += new System.EventHandler(this.Table13_MouseLeave);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.panel4.Controls.Add(this.Table18);
            this.panel4.Controls.Add(this.Table17);
            this.panel4.Controls.Add(this.Table16);
            this.panel4.Controls.Add(this.Table15);
            this.panel4.Location = new System.Drawing.Point(487, 121);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(498, 196);
            this.panel4.TabIndex = 18;
            // 
            // Table18
            // 
            this.Table18.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table18.Location = new System.Drawing.Point(283, 113);
            this.Table18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table18.Name = "Table18";
            this.Table18.Size = new System.Drawing.Size(94, 66);
            this.Table18.TabIndex = 24;
            this.Table18.UseVisualStyleBackColor = false;
            this.Table18.Click += new System.EventHandler(this.Table18_Click);
            this.Table18.MouseEnter += new System.EventHandler(this.Table18_MouseEnter);
            this.Table18.MouseLeave += new System.EventHandler(this.Table18_MouseLeave);
            // 
            // Table17
            // 
            this.Table17.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table17.Location = new System.Drawing.Point(130, 113);
            this.Table17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table17.Name = "Table17";
            this.Table17.Size = new System.Drawing.Size(94, 66);
            this.Table17.TabIndex = 23;
            this.Table17.UseVisualStyleBackColor = false;
            this.Table17.Click += new System.EventHandler(this.Table17_Click);
            this.Table17.MouseEnter += new System.EventHandler(this.Table17_MouseEnter);
            this.Table17.MouseLeave += new System.EventHandler(this.Table17_MouseLeave);
            // 
            // Table16
            // 
            this.Table16.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table16.Location = new System.Drawing.Point(283, 22);
            this.Table16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table16.Name = "Table16";
            this.Table16.Size = new System.Drawing.Size(94, 66);
            this.Table16.TabIndex = 20;
            this.Table16.UseVisualStyleBackColor = false;
            this.Table16.Click += new System.EventHandler(this.Table16_Click);
            this.Table16.MouseEnter += new System.EventHandler(this.Table16_MouseEnter);
            this.Table16.MouseLeave += new System.EventHandler(this.Table16_MouseLeave);
            // 
            // Table15
            // 
            this.Table15.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table15.Location = new System.Drawing.Point(130, 22);
            this.Table15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table15.Name = "Table15";
            this.Table15.Size = new System.Drawing.Size(94, 66);
            this.Table15.TabIndex = 19;
            this.Table15.UseVisualStyleBackColor = false;
            this.Table15.Click += new System.EventHandler(this.Table15_Click);
            this.Table15.MouseEnter += new System.EventHandler(this.Table15_MouseEnter);
            this.Table15.MouseLeave += new System.EventHandler(this.Table15_MouseLeave);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.panel5.Controls.Add(this.Table110);
            this.panel5.Controls.Add(this.Table19);
            this.panel5.Location = new System.Drawing.Point(487, 323);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(498, 164);
            this.panel5.TabIndex = 19;
            // 
            // Table110
            // 
            this.Table110.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table110.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table110.Location = new System.Drawing.Point(283, 57);
            this.Table110.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table110.Name = "Table110";
            this.Table110.Size = new System.Drawing.Size(94, 66);
            this.Table110.TabIndex = 27;
            this.Table110.UseVisualStyleBackColor = false;
            this.Table110.Click += new System.EventHandler(this.Table110_Click);
            this.Table110.MouseEnter += new System.EventHandler(this.Table110_MouseEnter);
            this.Table110.MouseLeave += new System.EventHandler(this.Table110_MouseLeave);
            // 
            // Table19
            // 
            this.Table19.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table19.Location = new System.Drawing.Point(130, 57);
            this.Table19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table19.Name = "Table19";
            this.Table19.Size = new System.Drawing.Size(94, 66);
            this.Table19.TabIndex = 23;
            this.Table19.UseVisualStyleBackColor = false;
            this.Table19.Click += new System.EventHandler(this.Table19_Click);
            this.Table19.MouseEnter += new System.EventHandler(this.Table19_MouseEnter);
            this.Table19.MouseLeave += new System.EventHandler(this.Table19_MouseLeave);
            // 
            // OfficeMap1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(236)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(1006, 507);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "OfficeMap1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OfficeMap";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.OfficeMap1_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.OfficeMap1_MouseMove);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HeaderLogo)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label CloseButton;
        private System.Windows.Forms.PictureBox HeaderLogo;
        private System.Windows.Forms.Button PerAccRedButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button floor1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button floop3;
        private System.Windows.Forms.Button floop2;
        private System.Windows.Forms.Button Table11;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button Table13;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button Table14;
        private System.Windows.Forms.Button Table12;
        private System.Windows.Forms.Button Table18;
        private System.Windows.Forms.Button Table17;
        private System.Windows.Forms.Button Table16;
        private System.Windows.Forms.Button Table15;
        private System.Windows.Forms.Button Table19;
        private System.Windows.Forms.Button Table110;
    }
}