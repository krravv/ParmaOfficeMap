﻿namespace Parma_Project.OfficeMap
{
    partial class OfficeMap2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PerAccRedButton = new System.Windows.Forms.Button();
            this.CloseButton = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.floop3 = new System.Windows.Forms.Button();
            this.floop2 = new System.Windows.Forms.Button();
            this.floor1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Table24 = new System.Windows.Forms.Button();
            this.Table21 = new System.Windows.Forms.Button();
            this.Table23 = new System.Windows.Forms.Button();
            this.Table22 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Table14 = new System.Windows.Forms.Button();
            this.Table13 = new System.Windows.Forms.Button();
            this.Table27 = new System.Windows.Forms.Button();
            this.Table25 = new System.Windows.Forms.Button();
            this.Table26 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Table28 = new System.Windows.Forms.Button();
            this.Table210 = new System.Windows.Forms.Button();
            this.Table29 = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // PerAccRedButton
            // 
            this.PerAccRedButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.PerAccRedButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PerAccRedButton.FlatAppearance.BorderSize = 0;
            this.PerAccRedButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PerAccRedButton.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PerAccRedButton.ForeColor = System.Drawing.Color.White;
            this.PerAccRedButton.Location = new System.Drawing.Point(629, 29);
            this.PerAccRedButton.Name = "PerAccRedButton";
            this.PerAccRedButton.Size = new System.Drawing.Size(342, 38);
            this.PerAccRedButton.TabIndex = 10;
            this.PerAccRedButton.Text = "Перейти в Личный кабинет";
            this.PerAccRedButton.UseVisualStyleBackColor = false;
            this.PerAccRedButton.Click += new System.EventHandler(this.PerAccRedButton_Click);
            // 
            // CloseButton
            // 
            this.CloseButton.AutoSize = true;
            this.CloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.CloseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CloseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CloseButton.ForeColor = System.Drawing.Color.White;
            this.CloseButton.Location = new System.Drawing.Point(977, 0);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(30, 29);
            this.CloseButton.TabIndex = 11;
            this.CloseButton.Text = "X";
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.floop3);
            this.panel2.Controls.Add(this.floop2);
            this.panel2.Controls.Add(this.floor1);
            this.panel2.Location = new System.Drawing.Point(22, 121);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(152, 242);
            this.panel2.TabIndex = 12;
            // 
            // floop3
            // 
            this.floop3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.floop3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.floop3.FlatAppearance.BorderSize = 0;
            this.floop3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.floop3.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.floop3.ForeColor = System.Drawing.Color.White;
            this.floop3.Location = new System.Drawing.Point(17, 161);
            this.floop3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.floop3.Name = "floop3";
            this.floop3.Size = new System.Drawing.Size(117, 58);
            this.floop3.TabIndex = 9;
            this.floop3.Text = "3 этаж";
            this.floop3.UseVisualStyleBackColor = false;
            this.floop3.Click += new System.EventHandler(this.floop3_Click);
            // 
            // floop2
            // 
            this.floop2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.floop2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.floop2.FlatAppearance.BorderSize = 0;
            this.floop2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.floop2.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.floop2.ForeColor = System.Drawing.Color.White;
            this.floop2.Location = new System.Drawing.Point(17, 90);
            this.floop2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.floop2.Name = "floop2";
            this.floop2.Size = new System.Drawing.Size(117, 58);
            this.floop2.TabIndex = 8;
            this.floop2.Text = "2 этаж";
            this.floop2.UseVisualStyleBackColor = false;
            // 
            // floor1
            // 
            this.floor1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.floor1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.floor1.FlatAppearance.BorderSize = 0;
            this.floor1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.floor1.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.floor1.ForeColor = System.Drawing.Color.White;
            this.floor1.Location = new System.Drawing.Point(17, 20);
            this.floor1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.floor1.Name = "floor1";
            this.floor1.Size = new System.Drawing.Size(117, 58);
            this.floor1.TabIndex = 7;
            this.floor1.Text = "1 этаж";
            this.floor1.UseVisualStyleBackColor = false;
            this.floor1.Click += new System.EventHandler(this.floor1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Image = global::Parma_Project.Properties.Resources.PARMA_TG_logo_с_охранным_полем_01;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1006, 103);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.panel3.Controls.Add(this.Table24);
            this.panel3.Controls.Add(this.Table21);
            this.panel3.Controls.Add(this.Table23);
            this.panel3.Controls.Add(this.Table22);
            this.panel3.Location = new System.Drawing.Point(196, 121);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(270, 366);
            this.panel3.TabIndex = 13;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // Table24
            // 
            this.Table24.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Table24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Table24.Location = new System.Drawing.Point(137, 219);
            this.Table24.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table24.Name = "Table24";
            this.Table24.Size = new System.Drawing.Size(94, 66);
            this.Table24.TabIndex = 33;
            this.Table24.UseVisualStyleBackColor = false;
            this.Table24.Click += new System.EventHandler(this.Table24_Click);
            this.Table24.MouseEnter += new System.EventHandler(this.Table24_MouseEnter);
            this.Table24.MouseLeave += new System.EventHandler(this.Table24_MouseLeave);
            // 
            // Table21
            // 
            this.Table21.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table21.Location = new System.Drawing.Point(22, 75);
            this.Table21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table21.Name = "Table21";
            this.Table21.Size = new System.Drawing.Size(94, 66);
            this.Table21.TabIndex = 32;
            this.Table21.UseVisualStyleBackColor = false;
            this.Table21.Click += new System.EventHandler(this.Table21_Click);
            this.Table21.MouseEnter += new System.EventHandler(this.Table21_MouseEnter);
            this.Table21.MouseLeave += new System.EventHandler(this.Table21_MouseLeave);
            // 
            // Table23
            // 
            this.Table23.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Table23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Table23.Location = new System.Drawing.Point(22, 219);
            this.Table23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table23.Name = "Table23";
            this.Table23.Size = new System.Drawing.Size(94, 66);
            this.Table23.TabIndex = 28;
            this.Table23.UseVisualStyleBackColor = false;
            this.Table23.Click += new System.EventHandler(this.Table23_Click);
            this.Table23.MouseEnter += new System.EventHandler(this.Table23_MouseEnter);
            this.Table23.MouseLeave += new System.EventHandler(this.Table23_MouseLeave);
            // 
            // Table22
            // 
            this.Table22.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table22.Location = new System.Drawing.Point(137, 75);
            this.Table22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table22.Name = "Table22";
            this.Table22.Size = new System.Drawing.Size(94, 66);
            this.Table22.TabIndex = 31;
            this.Table22.UseVisualStyleBackColor = false;
            this.Table22.Click += new System.EventHandler(this.Table22_Click);
            this.Table22.MouseEnter += new System.EventHandler(this.Table22_MouseEnter);
            this.Table22.MouseLeave += new System.EventHandler(this.Table22_MouseLeave);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.panel4.Controls.Add(this.Table14);
            this.panel4.Controls.Add(this.Table13);
            this.panel4.Controls.Add(this.Table27);
            this.panel4.Controls.Add(this.Table25);
            this.panel4.Controls.Add(this.Table26);
            this.panel4.Location = new System.Drawing.Point(488, 121);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(498, 196);
            this.panel4.TabIndex = 19;
            // 
            // Table14
            // 
            this.Table14.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table14.Location = new System.Drawing.Point(168, 277);
            this.Table14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table14.Name = "Table14";
            this.Table14.Size = new System.Drawing.Size(94, 66);
            this.Table14.TabIndex = 32;
            this.Table14.UseVisualStyleBackColor = false;
            // 
            // Table13
            // 
            this.Table13.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table13.Location = new System.Drawing.Point(36, 194);
            this.Table13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table13.Name = "Table13";
            this.Table13.Size = new System.Drawing.Size(94, 66);
            this.Table13.TabIndex = 29;
            this.Table13.UseVisualStyleBackColor = false;
            // 
            // Table27
            // 
            this.Table27.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table27.Location = new System.Drawing.Point(375, 20);
            this.Table27.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table27.Name = "Table27";
            this.Table27.Size = new System.Drawing.Size(94, 66);
            this.Table27.TabIndex = 33;
            this.Table27.UseVisualStyleBackColor = false;
            this.Table27.Click += new System.EventHandler(this.Table27_Click);
            this.Table27.MouseEnter += new System.EventHandler(this.Table27_MouseEnter);
            this.Table27.MouseLeave += new System.EventHandler(this.Table27_MouseLeave);
            // 
            // Table25
            // 
            this.Table25.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table25.Location = new System.Drawing.Point(36, 20);
            this.Table25.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table25.Name = "Table25";
            this.Table25.Size = new System.Drawing.Size(94, 66);
            this.Table25.TabIndex = 34;
            this.Table25.UseVisualStyleBackColor = false;
            this.Table25.Click += new System.EventHandler(this.Table25_Click);
            this.Table25.MouseEnter += new System.EventHandler(this.Table25_MouseEnter);
            this.Table25.MouseLeave += new System.EventHandler(this.Table25_MouseLeave);
            // 
            // Table26
            // 
            this.Table26.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table26.Location = new System.Drawing.Point(214, 101);
            this.Table26.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table26.Name = "Table26";
            this.Table26.Size = new System.Drawing.Size(94, 66);
            this.Table26.TabIndex = 35;
            this.Table26.UseVisualStyleBackColor = false;
            this.Table26.Click += new System.EventHandler(this.Table26_Click);
            this.Table26.MouseEnter += new System.EventHandler(this.Table26_MouseEnter);
            this.Table26.MouseLeave += new System.EventHandler(this.Table26_MouseLeave);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.panel5.Controls.Add(this.Table28);
            this.panel5.Controls.Add(this.Table210);
            this.panel5.Controls.Add(this.Table29);
            this.panel5.Location = new System.Drawing.Point(488, 323);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(498, 164);
            this.panel5.TabIndex = 23;
            // 
            // Table28
            // 
            this.Table28.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table28.Location = new System.Drawing.Point(375, 75);
            this.Table28.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table28.Name = "Table28";
            this.Table28.Size = new System.Drawing.Size(94, 66);
            this.Table28.TabIndex = 36;
            this.Table28.UseVisualStyleBackColor = false;
            this.Table28.Click += new System.EventHandler(this.Table28_Click);
            this.Table28.MouseEnter += new System.EventHandler(this.Table28_MouseEnter);
            this.Table28.MouseLeave += new System.EventHandler(this.Table28_MouseLeave);
            // 
            // Table210
            // 
            this.Table210.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table210.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table210.Location = new System.Drawing.Point(36, 75);
            this.Table210.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table210.Name = "Table210";
            this.Table210.Size = new System.Drawing.Size(94, 66);
            this.Table210.TabIndex = 37;
            this.Table210.UseVisualStyleBackColor = false;
            this.Table210.Click += new System.EventHandler(this.Table210_Click);
            this.Table210.MouseEnter += new System.EventHandler(this.Table210_MouseEnter);
            this.Table210.MouseLeave += new System.EventHandler(this.Table210_MouseLeave);
            // 
            // Table29
            // 
            this.Table29.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Table29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Table29.Location = new System.Drawing.Point(214, 75);
            this.Table29.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table29.Name = "Table29";
            this.Table29.Size = new System.Drawing.Size(94, 66);
            this.Table29.TabIndex = 30;
            this.Table29.UseVisualStyleBackColor = false;
            this.Table29.Click += new System.EventHandler(this.Table29_Click);
            this.Table29.MouseEnter += new System.EventHandler(this.Table29_MouseEnter);
            this.Table29.MouseLeave += new System.EventHandler(this.Table29_MouseLeave);
            // 
            // OfficeMap2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1006, 507);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.PerAccRedButton);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "OfficeMap2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OfficeMap2";
            this.Load += new System.EventHandler(this.OfficeMap2_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.OfficeMap2_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.OfficeMap2_MouseMove);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button PerAccRedButton;
        private System.Windows.Forms.Label CloseButton;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button floop3;
        private System.Windows.Forms.Button floop2;
        private System.Windows.Forms.Button floor1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button Table23;
        private System.Windows.Forms.Button Table22;
        private System.Windows.Forms.Button Table14;
        private System.Windows.Forms.Button Table13;
        private System.Windows.Forms.Button Table27;
        private System.Windows.Forms.Button Table25;
        private System.Windows.Forms.Button Table26;
        private System.Windows.Forms.Button Table28;
        private System.Windows.Forms.Button Table210;
        private System.Windows.Forms.Button Table29;
        private System.Windows.Forms.Button Table24;
        private System.Windows.Forms.Button Table21;
    }
}