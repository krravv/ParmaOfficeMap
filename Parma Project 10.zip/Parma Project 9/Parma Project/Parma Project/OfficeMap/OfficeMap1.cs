﻿using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;
using Parma_Project.PersonalAccountAdmin;
using Parma_Project.Рабочие_места;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parma_Project
{
    public partial class OfficeMap1 : Form
    {
        String IdUser = "";
        FreePlace FreePlace;
        OccupiedPlace OccupiedPlace;
        bool AdminMode;
        private void UpdateTypeBooking(string idTable)
        {
            DB db = new DB();
            MySqlDataAdapter adapter1 = new MySqlDataAdapter();
            DataTable table1 = new DataTable();
            db.openConnection();
            MySqlCommand command1 = new MySqlCommand("SELECT * FROM `booking history` WHERE `id table` = @idTable", db.getConnection());
            command1.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            db.closeConnection();

            bool flag = false;
            foreach (DataRow row in table1.Rows)
            {
                DateTime period1 = DateTime.ParseExact(row[1].ToString(), "dd.MM.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                DateTime period2 = DateTime.ParseExact(row[2].ToString(), "dd.MM.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                if (period1 <= DateTime.Today && period2 >= DateTime.Today)
                {
                    db.openConnection();
                    MySqlCommand command = new MySqlCommand("UPDATE `booking` SET `type`= '2' WHERE `number` = @idTable", db.getConnection());
                    command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                    command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                    command = new MySqlCommand("UPDATE `booking` SET `period1`= @period1 WHERE `number` = @idTable", db.getConnection());
                    command.Parameters.Add("@period1", MySqlDbType.VarChar).Value = row[1].ToString();
                    command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                    command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                    command = new MySqlCommand("UPDATE `booking` SET `period2`= @period2 WHERE `number` = @idTable", db.getConnection());
                    command.Parameters.Add("@period2", MySqlDbType.VarChar).Value = row[2].ToString();
                    command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                    command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                    command = new MySqlCommand("UPDATE `booking` SET `id employee`=  @idUser WHERE `number` = @idTable", db.getConnection());
                    command.Parameters.Add("@idUser", MySqlDbType.VarChar).Value = row[3].ToString();
                    command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                    command.ExecuteNonQuery();
                    db.closeConnection();
                    flag = true; break;
                }
            }
            if (!flag)
            {
                db.openConnection();
                MySqlCommand command = new MySqlCommand("UPDATE `booking` SET `type`= '1' WHERE `number` = @idTable", db.getConnection());
                command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                command = new MySqlCommand("UPDATE `booking` SET `period1`= @period1 WHERE `number` = @idTable", db.getConnection());
                command.Parameters.Add("@period1", MySqlDbType.VarChar).Value = "";
                command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                command = new MySqlCommand("UPDATE `booking` SET `period2`= @period2 WHERE `number` = @idTable", db.getConnection());
                command.Parameters.Add("@period2", MySqlDbType.VarChar).Value = "";
                command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                command = new MySqlCommand("UPDATE `booking` SET `id employee`=  @idUser WHERE `number` = @idTable", db.getConnection());
                command.Parameters.Add("@idUser", MySqlDbType.VarChar).Value = "";
                command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                command.ExecuteNonQuery();
                db.closeConnection();
            }
        }
        private void Table_MouseEnter(string idTable, int colorOrbook) //открытие окошка свободного/занятого места при наведении
        {
            UpdateTypeBooking(idTable);

            DB db = new DB(); 
            string type;
            db.openConnection(); //type 1 - не забронено, 2 - забронено
            MySqlCommand command = new MySqlCommand("SELECT type FROM `booking` WHERE `number` = @usID", db.getConnection());
            command.Parameters.Add("@usID", MySqlDbType.VarChar).Value = idTable;
            type = command.ExecuteScalar().ToString();

            if (colorOrbook == 1)
            {
                if (type == "1")
                {
                    this.FreePlace = new FreePlace(idTable);
                    this.FreePlace.Location = MousePosition;
                    this.FreePlace.Show();
                }
                else
                {
                    if (type == "2")
                    {
                        this.OccupiedPlace = new OccupiedPlace(idTable);
                        this.OccupiedPlace.Location = MousePosition;
                        this.OccupiedPlace.Show();
                    }
                    else
                    {
                        MessageBox.Show("Error, type off");
                    }
                }
            }
            else
            {
                string stable = "Table";
                if (int.Parse(idTable) <= 10) stable += "1" + idTable;
                else
                {
                    if (int.Parse(idTable) <= 20) stable += "2" + idTable;
                    else if (int.Parse(idTable) <= 30) stable += "3" + idTable;
                }
                if (type == "2")
                {
                    switch (stable)
                    {
                        case "Table11":
                            Table11.BackColor = Color.Crimson;
                            break;
                        case "Table12":
                            Table12.BackColor = Color.Crimson;
                            break;
                        case "Table13":
                            Table13.BackColor = Color.Crimson;
                            break;
                        case "Table14":
                            Table14.BackColor = Color.Crimson;
                            break;
                        case "Table15":
                            Table15.BackColor = Color.Crimson;
                            break;
                        case "Table16":
                            Table16.BackColor = Color.Crimson;
                            break;
                        case "Table17":
                            Table17.BackColor = Color.Crimson;
                            break;
                        case "Table18":
                            Table18.BackColor = Color.Crimson;
                            break;
                        case "Table19":
                            Table19.BackColor = Color.Crimson;
                            break;
                        case "Table110":
                            Table110.BackColor = Color.Crimson;
                            break;
                        default: break;
                    }
                }
            }
            db.closeConnection();
        }

        public OfficeMap1(String IDuser)
        {
            ClearHistoryBooking();
            this.IdUser = IDuser;
            FreePlace = new FreePlace("0employee");
            OccupiedPlace = new OccupiedPlace("0");
            this.AdminMode = false;
            InitializeComponent();
            Table_MouseEnter("1", 2); Table_MouseEnter("2", 2); Table_MouseEnter("3", 2);
            Table_MouseEnter("4", 2); Table_MouseEnter("5", 2); Table_MouseEnter("6", 2);
            Table_MouseEnter("7", 2); Table_MouseEnter("8", 2); Table_MouseEnter("9", 2); Table_MouseEnter("10", 2);
        }

        public OfficeMap1(String IDuser, bool admin)
        {
            ClearHistoryBooking();
            this.IdUser = IDuser;
            FreePlace = new FreePlace("1");
            OccupiedPlace = new OccupiedPlace("1");

            this.AdminMode = admin;
            Button button = new Button();
            button.Text = "Вернуться в ЛК Админа";
            button.Font = new Font("Montserrat", 12, FontStyle.Regular);
            button.ForeColor = Color.White;
            button.BackColor = Color.FromArgb(255, 67, 70);
            button.AutoSize = true;
            button.Location = new Point(39, 29);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.Name = "BackAdminButton";
            button.Click += new EventHandler(BackAdminButton_Click);
            this.Controls.Add(button);

            InitializeComponent();
            Table_MouseEnter("1", 2); Table_MouseEnter("2", 2); Table_MouseEnter("3", 2);
            Table_MouseEnter("4", 2); Table_MouseEnter("5", 2); Table_MouseEnter("6", 2);
            Table_MouseEnter("7", 2); Table_MouseEnter("8", 2); Table_MouseEnter("9", 2); Table_MouseEnter("10", 2);
        }
        private void ClearHistoryBooking()
        {
            DB db = new DB();
            db.openConnection();
            MySqlCommand command = new MySqlCommand("SELECT * FROM `booking history`", db.getConnection());
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataSet ds = new DataSet();
            adapter.Fill(ds);
            db.closeConnection();
            System.Data.DataTable dt = new System.Data.DataTable(); dt = ds.Tables[0];
            foreach (DataRow row in dt.Rows)
            {
                string idTable = row[0].ToString(), idUser = row[3].ToString();
                DateTime Period1 = DateTime.ParseExact(row[1].ToString(), "dd.MM.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                DateTime Period2 = DateTime.ParseExact(row[2].ToString(), "dd.MM.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                
                if ((DateTime.Today - Period2).TotalDays >= 184)
                {
                    db.openConnection();
                    command = new MySqlCommand("DELETE FROM `booking history` WHERE " +
                        "`id table` = @idTable, `period1` = @period1, `period2` = @period2,`id employee` = @idUser", db.getConnection());
                    command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                    command.Parameters.Add("@date1", MySqlDbType.VarChar).Value = Period1.ToShortDateString();
                    command.Parameters.Add("@date2", MySqlDbType.VarChar).Value = Period2.ToShortDateString();
                    command.Parameters.Add("@idUser", MySqlDbType.VarChar).Value = idUser;
                    command.ExecuteNonQuery();
                    db.closeConnection();
                }
            }
        }
            private void BackAdminButton_Click(object sender, EventArgs e)
        {
            FunctionsAdmin admin = new FunctionsAdmin();
            admin.Show();
            this.Close();
        }
        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        //ВОЗМОЖНОСТЬ ПЕРЕДВИЖЕНИЯ ОКНА ПРОГРАММЫ
        Point lastPoint; //точка последнего местоположения мыши
        private void OfficeMap1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void OfficeMap1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void HeaderLogo_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void HeaderLogo_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void floop2_Click(object sender, EventArgs e) //переход на второй этаж
        {
            if (!AdminMode)
            {
                OfficeMap.OfficeMap2 officeMap2 = new OfficeMap.OfficeMap2(this.IdUser);
                officeMap2.Show();
                this.Close();
            }
            else
            {
                OfficeMap.OfficeMap2 officeMap2 = new OfficeMap.OfficeMap2(this.IdUser, true);
                officeMap2.Show();
                this.Close();
            }
        }

        private void floop3_Click(object sender, EventArgs e) //переход на третий этаж
        {
            if (!AdminMode)
            {
                OfficeMap.OfficeMap3 officeMap3 = new OfficeMap.OfficeMap3(this.IdUser);
                officeMap3.Show();
                this.Close();
            }
            else
            {
                OfficeMap.OfficeMap3 officeMap3 = new OfficeMap.OfficeMap3(this.IdUser, true);
                officeMap3.Show();
                this.Close();
            }
        }

        private void PerAccRedButton_Click(object sender, EventArgs e) //переход в Личный кабинет на страницу редакции
        {
            if (!AdminMode)
            {
                PersonalAccountEmlpoyee personalAccount = new PersonalAccountEmlpoyee(this.IdUser);
                personalAccount.Show();
                this.Close();
            }
            else
            {
                PersonalAccountEmlpoyee personalAccount = new PersonalAccountEmlpoyee(this.IdUser, true);
                personalAccount.Show();
                this.Close();
            }
        }
        private void Table_MouseLeave(string idTable) //при уходе с рабочего места закрываем окошко
        {
            if (Application.OpenForms["FreePlace"] != null)
            {
                this.FreePlace.Close();
                this.FreePlace = new FreePlace(idTable);
            }
            else
                if (Application.OpenForms["OccupiedPlace"] != null)
                {
                    this.OccupiedPlace.Close();
                    this.OccupiedPlace = new OccupiedPlace(idTable);
                }
        }
        private void Table11_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("1",1);
        }

        private void Table11_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("1");
        }

        private void Table12_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("2",1);
        }

        private void Table12_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("2");
        }

        private void Table13_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("3",1);
        }

        private void Table13_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("3");
        }

        private void Table14_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("4",1);
        }

        private void Table14_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("4");
        }

        private void Table15_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("5",1);
        }

        private void Table15_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("5");
        }

        private void Table16_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("6",1);
        }

        private void Table16_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("6");
        }

        private void Table17_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("7",1);
        }

        private void Table17_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("7");
        }

        private void Table18_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("8",1);
        }

        private void Table18_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("8");
        }

        private void Table19_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("9",1);
        }

        private void Table19_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("9");
        }

        private void Table110_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("10",1);
        }

        private void Table110_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("10");
        }

        private void Book_Table(string idTable) //забронирвоать место
        {
            BookingPlace booking = new BookingPlace(this.IdUser, idTable);
            booking.Show();
        }

        private void Table11_Click(object sender, EventArgs e)
        {
            Book_Table("1");
        }

        private void Table12_Click(object sender, EventArgs e)
        {
            Book_Table("2");
        }

        private void Table13_Click(object sender, EventArgs e)
        {
            Book_Table("3");
        }

        private void Table14_Click(object sender, EventArgs e)
        {
            Book_Table("4");
        }

        private void Table15_Click(object sender, EventArgs e)
        {
            Book_Table("5");
        }

        private void Table16_Click(object sender, EventArgs e)
        {
            Book_Table("6");
        }

        private void Table17_Click(object sender, EventArgs e)
        {
            Book_Table("7");
        }

        private void Table18_Click(object sender, EventArgs e)
        {
            Book_Table("8");
        }

        private void Table19_Click(object sender, EventArgs e)
        {
            Book_Table("9");
        }

        private void Table110_Click(object sender, EventArgs e)
        {
            Book_Table("10");
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
