﻿using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;
using Parma_Project.PersonalAccountAdmin;
using Parma_Project.Рабочие_места;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parma_Project.OfficeMap
{
    public partial class OfficeMap3 : Form
    {
        String IdBox = "";
        FreePlace FreePlace;
        OccupiedPlace OccupiedPlace;
        bool AdminMode;
        private void UpdateTypeBooking(string idTable)
        {
            DB db = new DB();
            MySqlDataAdapter adapter1 = new MySqlDataAdapter();
            DataTable table1 = new DataTable();
            db.openConnection();
            MySqlCommand command1 = new MySqlCommand("SELECT * FROM `booking history` WHERE `id table` = @idTable", db.getConnection());
            command1.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            db.closeConnection();

            bool flag = false;
            foreach (DataRow row in table1.Rows)
            {
                DateTime period1 = DateTime.ParseExact(row[1].ToString(), "dd.MM.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                DateTime period2 = DateTime.ParseExact(row[2].ToString(), "dd.MM.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                if (period1 <= DateTime.Today && period2 >= DateTime.Today)
                {
                    db.openConnection();
                    MySqlCommand command = new MySqlCommand("UPDATE `booking` SET `type`= '2' WHERE `number` = @idTable", db.getConnection());
                    command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                    command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                    command = new MySqlCommand("UPDATE `booking` SET `period1`= @period1 WHERE `number` = @idTable", db.getConnection());
                    command.Parameters.Add("@period1", MySqlDbType.VarChar).Value = row[1].ToString();
                    command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                    command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                    command = new MySqlCommand("UPDATE `booking` SET `period2`= @period2 WHERE `number` = @idTable", db.getConnection());
                    command.Parameters.Add("@period2", MySqlDbType.VarChar).Value = row[2].ToString();
                    command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                    command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                    command = new MySqlCommand("UPDATE `booking` SET `id employee`=  @idUser WHERE `number` = @idTable", db.getConnection());
                    command.Parameters.Add("@idUser", MySqlDbType.VarChar).Value = row[3].ToString();
                    command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                    command.ExecuteNonQuery();
                    db.closeConnection();
                    flag = true; break;
                }
            }
            if (!flag)
            {
                db.openConnection();
                MySqlCommand command = new MySqlCommand("UPDATE `booking` SET `type`= '1' WHERE `number` = @idTable", db.getConnection());
                command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                command = new MySqlCommand("UPDATE `booking` SET `period1`= @period1 WHERE `number` = @idTable", db.getConnection());
                command.Parameters.Add("@period1", MySqlDbType.VarChar).Value = "";
                command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                command = new MySqlCommand("UPDATE `booking` SET `period2`= @period2 WHERE `number` = @idTable", db.getConnection());
                command.Parameters.Add("@period2", MySqlDbType.VarChar).Value = "";
                command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                command = new MySqlCommand("UPDATE `booking` SET `id employee`=  @idUser WHERE `number` = @idTable", db.getConnection());
                command.Parameters.Add("@idUser", MySqlDbType.VarChar).Value = "";
                command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                command.ExecuteNonQuery();
                db.closeConnection();
            }
        }
        private void Table_MouseEnter(string idTable, int colorOrbook) //открытие окошка свобдного/занятого места при наведении
        {
            UpdateTypeBooking(idTable);
            DB db = new DB();
            DataTable table = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            string type;
            db.openConnection(); //type 1 - не забронено, 2 - забронено
            MySqlCommand command = new MySqlCommand("SELECT type FROM `booking` WHERE `number` = @usID", db.getConnection());
            command.Parameters.Add("@usID", MySqlDbType.VarChar).Value = idTable;
            type = command.ExecuteScalar().ToString();

            if (colorOrbook == 1)
            {
                if (type == "1")
                {
                    this.FreePlace = new FreePlace(idTable);
                    this.FreePlace.Location = MousePosition;
                    this.FreePlace.Show();
                }
                else
                {
                    if (type == "2")
                    {
                        this.OccupiedPlace = new OccupiedPlace(idTable);
                        this.OccupiedPlace.Location = MousePosition;
                        this.OccupiedPlace.Show();
                    }
                    else
                    {
                        MessageBox.Show("Error, type off");
                    }
                }
            }
            else
            {
                string stable = "Table";
                if (int.Parse(idTable) <= 10) stable += "1" + idTable;
                else
                {
                    if (int.Parse(idTable) <= 20) stable += "2" + idTable;
                    else if (int.Parse(idTable) <= 30) stable += "3" + idTable;
                }
                if (type == "2")
                {
                    switch (stable)
                    {
                        case "Table321":
                            Table31.BackColor = Color.Crimson;
                            break;
                        case "Table322":
                            Table32.BackColor = Color.Crimson;
                            break;
                        case "Table323":
                            Table33.BackColor = Color.Crimson;
                            break;
                        case "Table324":
                            Table34.BackColor = Color.Crimson;
                            break;
                        case "Table325":
                            Table35.BackColor = Color.Crimson;
                            break;
                        case "Table326":
                            Table36.BackColor = Color.Crimson;
                            break;
                        case "Table327":
                            Table37.BackColor = Color.Crimson;
                            break;
                        case "Table328":
                            Table38.BackColor = Color.Crimson;
                            break;
                        case "Table329":
                            Table39.BackColor = Color.Crimson;
                            break;
                        case "Table330":
                            Table310.BackColor = Color.Crimson;
                            break;
                        default: break;
                    }
                }
            }
            db.closeConnection();
        }
        public OfficeMap3(String ID)
        {
            this.IdBox = ID;
            FreePlace = new FreePlace("21");
            OccupiedPlace = new OccupiedPlace("21");
            this.AdminMode = false;
            InitializeComponent();
            Table_MouseEnter("21", 2); Table_MouseEnter("22", 2); Table_MouseEnter("23", 2);
            Table_MouseEnter("24", 2); Table_MouseEnter("25", 2); Table_MouseEnter("26", 2);
            Table_MouseEnter("27", 2); Table_MouseEnter("28", 2); Table_MouseEnter("29", 2); Table_MouseEnter("30", 2);
        }
        public OfficeMap3(String IDuser, bool admin)
        {
            this.IdBox = IDuser;
            FreePlace = new FreePlace("21");
            OccupiedPlace = new OccupiedPlace("21");

            this.AdminMode = admin;
            Button button = new Button();
            button.Text = "Вернуться в ЛК Админа";
            button.Font = new Font("Montserrat", 12, FontStyle.Regular);
            button.ForeColor = Color.White;
            button.BackColor = Color.FromArgb(255, 67, 70);
            button.AutoSize = true;
            button.Location = new Point(39, 29);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.Name = "BackAdminButton";
            button.Click += new EventHandler(BackAdminButton_Click);
            this.Controls.Add(button);

            InitializeComponent();
            Table_MouseEnter("21", 2); Table_MouseEnter("22", 2); Table_MouseEnter("23", 2);
            Table_MouseEnter("24", 2); Table_MouseEnter("25", 2); Table_MouseEnter("26", 2);
            Table_MouseEnter("27", 2); Table_MouseEnter("28", 2); Table_MouseEnter("29", 2); Table_MouseEnter("30", 2);
        }

        private void BackAdminButton_Click(object sender, EventArgs e)
        {
            FunctionsAdmin admin = new FunctionsAdmin();
            admin.Show();
            this.Close();
        }
        private void PerAccRedButton_Click(object sender, EventArgs e) //переход в личный кабинет
        {
            PersonalAccountEmlpoyee personalAccount = new PersonalAccountEmlpoyee(IdBox);
            personalAccount.Show();
            this.Close();
        }

        private void CloseButton_Click(object sender, EventArgs e) //кнопка закрвтия приложения
        {
            this.Close();
            Application.Exit();
        }

        //ВОЗМОЖНОСТЬ ПЕРЕДВИЖЕНИЯ ОКНА ПРОГРАММЫ
        Point lastPoint; //точка последнего местоположения мыши
        private void OfficeMap3_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void OfficeMap3_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void floor1_Click(object sender, EventArgs e)
        {
            if (!AdminMode)
            {
                OfficeMap1 officeMap1 = new OfficeMap1(IdBox);
                officeMap1.Show();
                this.Close();
            }
            else
            {
                OfficeMap1 officeMap1 = new OfficeMap1(IdBox, true);
                officeMap1.Show();
                this.Close();
            }
        }

        private void floor2_Click(object sender, EventArgs e)
        {
            if (!AdminMode)
            {
                OfficeMap.OfficeMap2 officeMap2 = new OfficeMap.OfficeMap2(this.IdBox);
                officeMap2.Show();
                this.Close();
            }
            else
            {
                OfficeMap.OfficeMap2 officeMap2 = new OfficeMap.OfficeMap2(this.IdBox, true);
                officeMap2.Show();
                this.Close();
            }
        }
        private void Table_MouseLeave(string idTable) //при уходе с рабочего места закрываем окошко
        {
            if (Application.OpenForms["FreePlace"] != null)
            {
                this.FreePlace.Close();
                this.FreePlace = new FreePlace(idTable);
            }
            else
                if (Application.OpenForms["OccupiedPlace"] != null)
            {
                this.OccupiedPlace.Close();
                this.OccupiedPlace = new OccupiedPlace(idTable);
            }
        }
        private void Table31_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("21",1);
        }

        private void Table31_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("21");
        }

        private void Table32_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("22", 1);
        }

        private void Table32_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("22");
        }

        private void Table33_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("23", 1);
        }

        private void Table33_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("23");
        }

        private void Table34_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("24", 1);
        }

        private void Table34_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("24");
        }

        private void Table35_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("25", 1);
        }

        private void Table35_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("25");
        }

        private void Table36_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("26", 1);
        }

        private void Table36_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("26");
        }

        private void Table37_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("27", 1);
        }

        private void Table37_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("27");
        }

        private void Table38_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("28", 1);
        }

        private void Table38_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("28");
        }

        private void Table39_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("29", 1);
        }

        private void Table39_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("29");
        }

        private void Table310_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("30", 1);
        }

        private void Table310_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("30");
        }
        private void Book_Table(string idTable) //забронирвоать место
        {
            BookingPlace booking = new BookingPlace(this.IdBox, idTable);
            booking.Show();
        }
        private void Table31_Click(object sender, EventArgs e)
        {
            Book_Table("21");
        }

        private void Table32_Click(object sender, EventArgs e)
        {
            Book_Table("22");
        }

        private void Table33_Click(object sender, EventArgs e)
        {
            Book_Table("23");
        }

        private void Table34_Click(object sender, EventArgs e)
        {
            Book_Table("24");
        }

        private void Table35_Click(object sender, EventArgs e)
        {
            Book_Table("25");
        }

        private void Table36_Click(object sender, EventArgs e)
        {
            Book_Table("26");
        }

        private void Table37_Click(object sender, EventArgs e)
        {
            Book_Table("27");
        }

        private void Table38_Click(object sender, EventArgs e)
        {
            Book_Table("28");
        }

        private void Table39_Click(object sender, EventArgs e)
        {
            Book_Table("29");
        }

        private void Table310_Click(object sender, EventArgs e)
        {
            Book_Table("30");
        }
    }
}
