﻿namespace Parma_Project.OfficeMap
{
    partial class OfficeMap3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.floor3 = new System.Windows.Forms.Button();
            this.floor2 = new System.Windows.Forms.Button();
            this.floor1 = new System.Windows.Forms.Button();
            this.CloseButton = new System.Windows.Forms.Label();
            this.PerAccRedButton = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Table310 = new System.Windows.Forms.Button();
            this.Table38 = new System.Windows.Forms.Button();
            this.Table39 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Table32 = new System.Windows.Forms.Button();
            this.Table33 = new System.Windows.Forms.Button();
            this.Table31 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Table34 = new System.Windows.Forms.Button();
            this.Table36 = new System.Windows.Forms.Button();
            this.Table37 = new System.Windows.Forms.Button();
            this.Table35 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Image = global::Parma_Project.Properties.Resources.PARMA_TG_logo_с_охранным_полем_01;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1006, 103);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.floor3);
            this.panel1.Controls.Add(this.floor2);
            this.panel1.Controls.Add(this.floor1);
            this.panel1.Location = new System.Drawing.Point(22, 121);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(152, 242);
            this.panel1.TabIndex = 13;
            // 
            // floor3
            // 
            this.floor3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.floor3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.floor3.FlatAppearance.BorderSize = 0;
            this.floor3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.floor3.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.floor3.ForeColor = System.Drawing.Color.White;
            this.floor3.Location = new System.Drawing.Point(17, 161);
            this.floor3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.floor3.Name = "floor3";
            this.floor3.Size = new System.Drawing.Size(117, 58);
            this.floor3.TabIndex = 9;
            this.floor3.Text = "3 этаж";
            this.floor3.UseVisualStyleBackColor = false;
            // 
            // floor2
            // 
            this.floor2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.floor2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.floor2.FlatAppearance.BorderSize = 0;
            this.floor2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.floor2.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.floor2.ForeColor = System.Drawing.Color.White;
            this.floor2.Location = new System.Drawing.Point(17, 90);
            this.floor2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.floor2.Name = "floor2";
            this.floor2.Size = new System.Drawing.Size(117, 58);
            this.floor2.TabIndex = 8;
            this.floor2.Text = "2 этаж";
            this.floor2.UseVisualStyleBackColor = false;
            this.floor2.Click += new System.EventHandler(this.floor2_Click);
            // 
            // floor1
            // 
            this.floor1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.floor1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.floor1.FlatAppearance.BorderSize = 0;
            this.floor1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.floor1.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.floor1.ForeColor = System.Drawing.Color.White;
            this.floor1.Location = new System.Drawing.Point(17, 20);
            this.floor1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.floor1.Name = "floor1";
            this.floor1.Size = new System.Drawing.Size(117, 58);
            this.floor1.TabIndex = 7;
            this.floor1.Text = "1 этаж";
            this.floor1.UseVisualStyleBackColor = false;
            this.floor1.Click += new System.EventHandler(this.floor1_Click);
            // 
            // CloseButton
            // 
            this.CloseButton.AutoSize = true;
            this.CloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.CloseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CloseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CloseButton.ForeColor = System.Drawing.Color.White;
            this.CloseButton.Location = new System.Drawing.Point(977, 0);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(30, 29);
            this.CloseButton.TabIndex = 14;
            this.CloseButton.Text = "X";
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // PerAccRedButton
            // 
            this.PerAccRedButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(67)))), ((int)(((byte)(70)))));
            this.PerAccRedButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PerAccRedButton.FlatAppearance.BorderSize = 0;
            this.PerAccRedButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PerAccRedButton.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PerAccRedButton.ForeColor = System.Drawing.Color.White;
            this.PerAccRedButton.Location = new System.Drawing.Point(629, 29);
            this.PerAccRedButton.Name = "PerAccRedButton";
            this.PerAccRedButton.Size = new System.Drawing.Size(342, 38);
            this.PerAccRedButton.TabIndex = 15;
            this.PerAccRedButton.Text = "Перейти в Личный кабинет";
            this.PerAccRedButton.UseVisualStyleBackColor = false;
            this.PerAccRedButton.Click += new System.EventHandler(this.PerAccRedButton_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.panel5.Controls.Add(this.Table310);
            this.panel5.Controls.Add(this.Table38);
            this.panel5.Controls.Add(this.Table39);
            this.panel5.Location = new System.Drawing.Point(487, 324);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(498, 164);
            this.panel5.TabIndex = 20;
            // 
            // Table310
            // 
            this.Table310.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table310.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Table310.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table310.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Table310.Location = new System.Drawing.Point(367, 75);
            this.Table310.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table310.Name = "Table310";
            this.Table310.Size = new System.Drawing.Size(94, 66);
            this.Table310.TabIndex = 42;
            this.Table310.UseVisualStyleBackColor = false;
            this.Table310.Click += new System.EventHandler(this.Table310_Click);
            this.Table310.MouseEnter += new System.EventHandler(this.Table310_MouseEnter);
            this.Table310.MouseLeave += new System.EventHandler(this.Table310_MouseLeave);
            // 
            // Table38
            // 
            this.Table38.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table38.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Table38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Table38.Location = new System.Drawing.Point(40, 75);
            this.Table38.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table38.Name = "Table38";
            this.Table38.Size = new System.Drawing.Size(94, 66);
            this.Table38.TabIndex = 38;
            this.Table38.UseVisualStyleBackColor = false;
            this.Table38.Click += new System.EventHandler(this.Table38_Click);
            this.Table38.MouseEnter += new System.EventHandler(this.Table38_MouseEnter);
            this.Table38.MouseLeave += new System.EventHandler(this.Table38_MouseLeave);
            // 
            // Table39
            // 
            this.Table39.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table39.Location = new System.Drawing.Point(199, 33);
            this.Table39.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table39.Name = "Table39";
            this.Table39.Size = new System.Drawing.Size(94, 66);
            this.Table39.TabIndex = 45;
            this.Table39.UseVisualStyleBackColor = false;
            this.Table39.Click += new System.EventHandler(this.Table39_Click);
            this.Table39.MouseEnter += new System.EventHandler(this.Table39_MouseEnter);
            this.Table39.MouseLeave += new System.EventHandler(this.Table39_MouseLeave);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.panel3.Controls.Add(this.Table32);
            this.panel3.Controls.Add(this.Table33);
            this.panel3.Controls.Add(this.Table31);
            this.panel3.Location = new System.Drawing.Point(197, 121);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(270, 366);
            this.panel3.TabIndex = 21;
            // 
            // Table32
            // 
            this.Table32.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table32.Location = new System.Drawing.Point(29, 153);
            this.Table32.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table32.Name = "Table32";
            this.Table32.Size = new System.Drawing.Size(94, 66);
            this.Table32.TabIndex = 41;
            this.Table32.UseVisualStyleBackColor = false;
            this.Table32.Click += new System.EventHandler(this.Table32_Click);
            this.Table32.MouseEnter += new System.EventHandler(this.Table32_MouseEnter);
            this.Table32.MouseLeave += new System.EventHandler(this.Table32_MouseLeave);
            // 
            // Table33
            // 
            this.Table33.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table33.Location = new System.Drawing.Point(147, 254);
            this.Table33.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table33.Name = "Table33";
            this.Table33.Size = new System.Drawing.Size(94, 66);
            this.Table33.TabIndex = 47;
            this.Table33.UseVisualStyleBackColor = false;
            this.Table33.Click += new System.EventHandler(this.Table33_Click);
            this.Table33.MouseEnter += new System.EventHandler(this.Table33_MouseEnter);
            this.Table33.MouseLeave += new System.EventHandler(this.Table33_MouseLeave);
            // 
            // Table31
            // 
            this.Table31.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table31.Location = new System.Drawing.Point(147, 44);
            this.Table31.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table31.Name = "Table31";
            this.Table31.Size = new System.Drawing.Size(94, 66);
            this.Table31.TabIndex = 44;
            this.Table31.UseVisualStyleBackColor = false;
            this.Table31.Click += new System.EventHandler(this.Table31_Click);
            this.Table31.MouseEnter += new System.EventHandler(this.Table31_MouseEnter);
            this.Table31.MouseLeave += new System.EventHandler(this.Table31_MouseLeave);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(50)))), ((int)(((byte)(64)))));
            this.panel4.Controls.Add(this.Table34);
            this.panel4.Controls.Add(this.Table36);
            this.panel4.Controls.Add(this.Table37);
            this.panel4.Controls.Add(this.Table35);
            this.panel4.Location = new System.Drawing.Point(487, 121);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(498, 196);
            this.panel4.TabIndex = 23;
            // 
            // Table34
            // 
            this.Table34.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table34.Location = new System.Drawing.Point(40, 68);
            this.Table34.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table34.Name = "Table34";
            this.Table34.Size = new System.Drawing.Size(94, 66);
            this.Table34.TabIndex = 40;
            this.Table34.UseVisualStyleBackColor = false;
            this.Table34.Click += new System.EventHandler(this.Table34_Click);
            this.Table34.MouseEnter += new System.EventHandler(this.Table34_MouseEnter);
            this.Table34.MouseLeave += new System.EventHandler(this.Table34_MouseLeave);
            // 
            // Table36
            // 
            this.Table36.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table36.Location = new System.Drawing.Point(199, 109);
            this.Table36.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table36.Name = "Table36";
            this.Table36.Size = new System.Drawing.Size(94, 66);
            this.Table36.TabIndex = 43;
            this.Table36.UseVisualStyleBackColor = false;
            this.Table36.Click += new System.EventHandler(this.Table36_Click);
            this.Table36.MouseEnter += new System.EventHandler(this.Table36_MouseEnter);
            this.Table36.MouseLeave += new System.EventHandler(this.Table36_MouseLeave);
            // 
            // Table37
            // 
            this.Table37.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table37.Location = new System.Drawing.Point(367, 68);
            this.Table37.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table37.Name = "Table37";
            this.Table37.Size = new System.Drawing.Size(94, 66);
            this.Table37.TabIndex = 46;
            this.Table37.UseVisualStyleBackColor = false;
            this.Table37.Click += new System.EventHandler(this.Table37_Click);
            this.Table37.MouseEnter += new System.EventHandler(this.Table37_MouseEnter);
            this.Table37.MouseLeave += new System.EventHandler(this.Table37_MouseLeave);
            // 
            // Table35
            // 
            this.Table35.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Table35.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Table35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Table35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Table35.Location = new System.Drawing.Point(199, 12);
            this.Table35.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Table35.Name = "Table35";
            this.Table35.Size = new System.Drawing.Size(94, 66);
            this.Table35.TabIndex = 39;
            this.Table35.UseVisualStyleBackColor = false;
            this.Table35.Click += new System.EventHandler(this.Table35_Click);
            this.Table35.MouseEnter += new System.EventHandler(this.Table35_MouseEnter);
            this.Table35.MouseLeave += new System.EventHandler(this.Table35_MouseLeave);
            // 
            // OfficeMap3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1006, 507);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.PerAccRedButton);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "OfficeMap3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OfficeMap3";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.OfficeMap3_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.OfficeMap3_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button floor3;
        private System.Windows.Forms.Button floor2;
        private System.Windows.Forms.Button floor1;
        private System.Windows.Forms.Label CloseButton;
        private System.Windows.Forms.Button PerAccRedButton;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button Table310;
        private System.Windows.Forms.Button Table38;
        private System.Windows.Forms.Button Table39;
        private System.Windows.Forms.Button Table32;
        private System.Windows.Forms.Button Table33;
        private System.Windows.Forms.Button Table31;
        private System.Windows.Forms.Button Table34;
        private System.Windows.Forms.Button Table36;
        private System.Windows.Forms.Button Table37;
        private System.Windows.Forms.Button Table35;
    }
}