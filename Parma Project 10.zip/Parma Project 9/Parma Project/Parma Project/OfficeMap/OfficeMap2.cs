﻿using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;
using Parma_Project.PersonalAccountAdmin;
using Parma_Project.Рабочие_места;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parma_Project.OfficeMap
{
    public partial class OfficeMap2 : Form
    {
        String IdBox = "";
        FreePlace FreePlace;
        OccupiedPlace OccupiedPlace;
        bool AdminMode;
        private void UpdateTypeBooking(string idTable)
        {
            DB db = new DB();
            MySqlDataAdapter adapter1 = new MySqlDataAdapter();
            DataTable table1 = new DataTable();
            db.openConnection();
            MySqlCommand command1 = new MySqlCommand("SELECT * FROM `booking history` WHERE `id table` = @idTable", db.getConnection());
            command1.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
            adapter1.SelectCommand = command1;
            adapter1.Fill(table1);
            db.closeConnection();

            bool flag = false;
            foreach (DataRow row in table1.Rows)
            {
                DateTime period1 = DateTime.ParseExact(row[1].ToString(), "dd.MM.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                DateTime period2 = DateTime.ParseExact(row[2].ToString(), "dd.MM.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                if (period1 <= DateTime.Today && period2 >= DateTime.Today)
                {
                    db.openConnection();
                    MySqlCommand command = new MySqlCommand("UPDATE `booking` SET `type`= '2' WHERE `number` = @idTable", db.getConnection());
                    command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                    command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                    command = new MySqlCommand("UPDATE `booking` SET `period1`= @period1 WHERE `number` = @idTable", db.getConnection());
                    command.Parameters.Add("@period1", MySqlDbType.VarChar).Value = row[1].ToString();
                    command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                    command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                    command = new MySqlCommand("UPDATE `booking` SET `period2`= @period2 WHERE `number` = @idTable", db.getConnection());
                    command.Parameters.Add("@period2", MySqlDbType.VarChar).Value = row[2].ToString();
                    command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                    command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                    command = new MySqlCommand("UPDATE `booking` SET `id employee`=  @idUser WHERE `number` = @idTable", db.getConnection());
                    command.Parameters.Add("@idUser", MySqlDbType.VarChar).Value = row[3].ToString();
                    command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                    command.ExecuteNonQuery();
                    db.closeConnection();
                    flag = true; break;
                }
            }
            if (!flag)
            {
                db.openConnection();
                MySqlCommand command = new MySqlCommand("UPDATE `booking` SET `type`= '1' WHERE `number` = @idTable", db.getConnection());
                command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                command = new MySqlCommand("UPDATE `booking` SET `period1`= @period1 WHERE `number` = @idTable", db.getConnection());
                command.Parameters.Add("@period1", MySqlDbType.VarChar).Value = "";
                command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                command = new MySqlCommand("UPDATE `booking` SET `period2`= @period2 WHERE `number` = @idTable", db.getConnection());
                command.Parameters.Add("@period2", MySqlDbType.VarChar).Value = "";
                command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                command.ExecuteNonQuery(); db.closeConnection(); db.openConnection();

                command = new MySqlCommand("UPDATE `booking` SET `id employee`=  @idUser WHERE `number` = @idTable", db.getConnection());
                command.Parameters.Add("@idUser", MySqlDbType.VarChar).Value = "";
                command.Parameters.Add("@idTable", MySqlDbType.VarChar).Value = idTable;
                command.ExecuteNonQuery();
                db.closeConnection();
            }
        }
        private void Table_MouseEnter(string idTable, int colorOrbook) //открытие окошка свобдного/занятого места при наведении
        {
            UpdateTypeBooking(idTable);

            DB db = new DB();
            DataTable table = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            string type;
            db.openConnection(); //type 1 - не забронено, 2 - забронено
            MySqlCommand command = new MySqlCommand("SELECT type FROM `booking` WHERE `number` = @usID", db.getConnection());
            command.Parameters.Add("@usID", MySqlDbType.VarChar).Value = idTable;
            type = command.ExecuteScalar().ToString();

            if (colorOrbook == 1)
            {
                if (type == "1")
                {
                    this.FreePlace = new FreePlace(idTable);
                    this.FreePlace.Location = MousePosition;
                    this.FreePlace.Show();
                }
                else
                {
                    if (type == "2")
                    {
                        this.OccupiedPlace = new OccupiedPlace(idTable);
                        this.OccupiedPlace.Location = MousePosition;
                        this.OccupiedPlace.Show();
                    }
                    else
                    {
                        MessageBox.Show("Error, type off");
                    }
                }
            }
            else
            {
                string stable = "Table";
                if (int.Parse(idTable) <= 10) stable += "1" + idTable;
                else
                {
                    if (int.Parse(idTable) <= 20) stable += "2" + idTable;
                    else if (int.Parse(idTable) <= 30) stable += "3" + idTable;
                }
                if (type == "2")
                {
                    switch (stable)
                    {
                        case "Table211":
                            Table21.BackColor = Color.Crimson;
                            break;
                        case "Table212":
                            Table22.BackColor = Color.Crimson;
                            break;
                        case "Table213":
                            Table23.BackColor = Color.Crimson;
                            break;
                        case "Table214":
                            Table24.BackColor = Color.Crimson;
                            break;
                        case "Table215":
                            Table25.BackColor = Color.Crimson;
                            break;
                        case "Table216":
                            Table26.BackColor = Color.Crimson;
                            break;
                        case "Table217":
                            Table27.BackColor = Color.Crimson;
                            break;
                        case "Table218":
                            Table28.BackColor = Color.Crimson;
                            break;
                        case "Table219":
                            Table29.BackColor = Color.Crimson;
                            break;
                        case "Table220":
                            Table210.BackColor = Color.Crimson;
                            break;
                        default: break;
                    }
                }
            }
            db.closeConnection();
        }
        public OfficeMap2(String IDUser)
        {
            this.IdBox = IDUser;
            FreePlace = new FreePlace("11");
            OccupiedPlace = new OccupiedPlace("11");
            this.AdminMode = false;
            InitializeComponent();
            Table_MouseEnter("11", 2); Table_MouseEnter("12", 2); Table_MouseEnter("13", 2);
            Table_MouseEnter("14", 2); Table_MouseEnter("15", 2); Table_MouseEnter("16", 2);
            Table_MouseEnter("17", 2); Table_MouseEnter("18", 2); Table_MouseEnter("19", 2); Table_MouseEnter("20", 2);
        }
        public OfficeMap2(String IDuser, bool admin)
        {
            this.IdBox = IDuser;
            FreePlace = new FreePlace("11");
            OccupiedPlace = new OccupiedPlace("11");

            this.AdminMode = admin;
            Button button = new Button();
            button.Text = "Вернуться в ЛК Админа";
            button.Font = new Font("Montserrat", 12, FontStyle.Regular);
            button.ForeColor = Color.White;
            button.BackColor = Color.FromArgb(255, 67, 70);
            button.AutoSize = true;
            button.Location = new Point(39, 29);
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.Name = "BackAdminButton";
            button.Click += new EventHandler(BackAdminButton_Click);
            this.Controls.Add(button);

            InitializeComponent();
            Table_MouseEnter("11", 2); Table_MouseEnter("12", 2); Table_MouseEnter("13", 2);
            Table_MouseEnter("14", 2); Table_MouseEnter("15", 2); Table_MouseEnter("16", 2);
            Table_MouseEnter("17", 2); Table_MouseEnter("18", 2); Table_MouseEnter("19", 2); Table_MouseEnter("20", 2);
        }
        private void BackAdminButton_Click(object sender, EventArgs e)
        {
            FunctionsAdmin admin = new FunctionsAdmin();
            admin.Show();
            this.Close();
        }
        private void OfficeMap2_Load(object sender, EventArgs e)
        {

        }
        //ВОЗМОЖНОСТЬ ПЕРЕДВИЖЕНИЯ ОКНА ПРОГРАММЫ
        Point lastPoint; //точка последнего местоположения мыши

        private void PerAccRedButton_Click(object sender, EventArgs e)
        {
            PersonalAccountEmlpoyee personalAccount = new PersonalAccountEmlpoyee(this.IdBox);
            personalAccount.Show();
            this.Close();
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void OfficeMap2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void OfficeMap2_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }
        ////////////////////////////////////////
        

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void floor1_Click(object sender, EventArgs e)
        {
            if (!AdminMode)
            {
                OfficeMap1 officeMap1 = new OfficeMap1(IdBox);
                officeMap1.Show();
                this.Close();
            }
            else
            {
                OfficeMap1 officeMap1 = new OfficeMap1(IdBox, true);
                officeMap1.Show();
                this.Close();
            }
        }

        private void floop3_Click(object sender, EventArgs e)
        {
            if (!AdminMode)
            {
                OfficeMap.OfficeMap3 officeMap3 = new OfficeMap.OfficeMap3(IdBox);
                officeMap3.Show();
                this.Close();
            }
            else
            {
                OfficeMap.OfficeMap3 officeMap3 = new OfficeMap.OfficeMap3(IdBox, true);
                officeMap3.Show();
                this.Close();
            }
        }

        private void Table_MouseLeave(string idTable) //при уходе с рабочего места закрываем окошко
        {
            if (Application.OpenForms["FreePlace"] != null)
            {
                this.FreePlace.Close();
                this.FreePlace = new FreePlace(idTable);
            }
            else
                if (Application.OpenForms["OccupiedPlace"] != null)
            {
                this.OccupiedPlace.Close();
                this.OccupiedPlace = new OccupiedPlace(idTable);
            }
        }

        private void Table21_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("11",1);
        }

        private void Table21_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("11");
        }

        private void Table22_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("12",1);
        }

        private void Table22_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("12");
        }

        private void Table23_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("13", 1);
        }

        private void Table23_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("13");
        }

        private void Table24_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("14", 1);
        }

        private void Table24_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("14");
        }

        private void Table25_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("15", 1);
        }

        private void Table25_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("15");
        }

        private void Table26_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("16", 1);
        }

        private void Table26_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("16");
        }

        private void Table27_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("17", 1);
        }

        private void Table27_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("17");
        }

        private void Table210_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("20", 1);
        }

        private void Table210_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("20");
        }

        private void Table29_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("19", 1);
        }

        private void Table29_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("19");
        }

        private void Table28_MouseEnter(object sender, EventArgs e)
        {
            Table_MouseEnter("18", 1);
        }

        private void Table28_MouseLeave(object sender, EventArgs e)
        {
            Table_MouseLeave("18");
        }
        private void Book_Table(string idTable) //забронирвоать место
        {
            BookingPlace booking = new BookingPlace(this.IdBox, idTable);
            booking.Show();
        }
        private void Table21_Click(object sender, EventArgs e)
        {
            Book_Table("11");
        }

        private void Table22_Click(object sender, EventArgs e)
        {
            Book_Table("12");
        }

        private void Table23_Click(object sender, EventArgs e)
        {
            Book_Table("13");
        }

        private void Table24_Click(object sender, EventArgs e)
        {
            Book_Table("14");
        }

        private void Table25_Click(object sender, EventArgs e)
        {
            Book_Table("15");
        }

        private void Table26_Click(object sender, EventArgs e)
        {
            Book_Table("16");
        }

        private void Table27_Click(object sender, EventArgs e)
        {
            Book_Table("17");
        }

        private void Table210_Click(object sender, EventArgs e)
        {
            Book_Table("20");
        }

        private void Table29_Click(object sender, EventArgs e)
        {
            Book_Table("19");
        }

        private void Table28_Click(object sender, EventArgs e)
        {
            Book_Table("18");
        }
    }
}
